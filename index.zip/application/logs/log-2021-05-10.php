<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-10 02:35:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:35:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:35:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 02:35:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:35:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:35:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 02:47:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:47:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:47:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 02:47:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 02:48:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:48:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-10 02:48:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:48:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:51:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'webnew' C:\xampp\htdocs\webfreight\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-10 02:51:15 --> Unable to connect to the database
ERROR - 2021-05-10 02:52:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:52:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:52:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:52:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:52:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:52:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:52:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:52:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:53:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:53:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:53:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:53:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:53:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:53:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 02:53:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 02:53:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:00:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:00:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:00:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:00:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:01:16 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-10 03:01:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:01:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:01:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:01:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:01:50 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-10 03:02:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:02:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:02:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:02:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:02:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:02:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:02:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:02:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:02:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:02:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:02:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:02:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:02:54 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-10 03:03:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:03:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:03:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:03:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:06:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:06:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:07:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:07:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:07:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:07:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:07:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:07:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:07:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:07:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:07:47 --> 404 Page Not Found: Customers/shipment
ERROR - 2021-05-10 03:07:50 --> 404 Page Not Found: Customers/shipment
ERROR - 2021-05-10 03:07:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:07:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:08:15 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-10 03:08:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-10 03:08:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:08:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:08:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:08:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:08:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:08:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:08:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:08:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:08:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:10:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:10:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:10:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:10:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:11:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:11:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:11:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:11:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:11:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:11:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:11:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:11:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:11:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:11:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:11:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:11:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:15:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:15:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:15:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:15:33 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:15:37 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-10 03:15:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:15:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:15:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:15:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:16:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:16:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:16:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:16:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:16:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:16:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:16:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:16:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-10 03:18:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:18:41 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:18:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:18:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:19:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:19:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:19:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:19:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:20:18 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-05-10 03:20:27 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-05-10 03:21:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:21:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:21:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:21:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:21:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:21:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:21:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:21:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:22:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:22:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:22:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:22:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:23:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:23:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:23:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:23:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:25:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:25:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:25:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:25:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:31:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:31:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:31:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:31:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:31:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:31:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:31:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:31:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:32:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:32:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:32:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:32:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:38:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:38:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:38:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:38:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:39:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:39:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:39:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:39:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 235
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 356
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 358
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 359
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 360
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 361
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 362
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 363
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 364
ERROR - 2021-05-10 03:49:00 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 365
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 294
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 142
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 145
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 147
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 158
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 159
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 160
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 256
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 261
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 266
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 276
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 284
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 289
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 294
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 471
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 472
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 473
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 474
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 475
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 476
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 481
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 482
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 483
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 484
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 485
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 486
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 487
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 492
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 493
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 494
ERROR - 2021-05-10 03:49:01 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 495
ERROR - 2021-05-10 03:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:49:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:49:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 58
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 65
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 73
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 83
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 83
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 1138
ERROR - 2021-05-10 03:49:05 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 1526
ERROR - 2021-05-10 03:49:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 58
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 65
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 73
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 83
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 83
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 836
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 1138
ERROR - 2021-05-10 03:49:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 1526
ERROR - 2021-05-10 03:49:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 62
ERROR - 2021-05-10 03:49:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 62
ERROR - 2021-05-10 03:49:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 62
ERROR - 2021-05-10 03:49:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 62
ERROR - 2021-05-10 03:49:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 62
ERROR - 2021-05-10 03:49:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:49:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:49:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:49:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:49:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:49:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:49:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:49:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:50:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:50:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:50:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:50:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:50:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:50:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:51:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:51:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $get_carrier C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $get_service C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 142
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 142
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 145
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 145
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 147
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 147
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 158
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 158
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 159
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 159
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 160
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 160
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 256
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 256
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 261
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 261
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 266
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 266
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 276
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 276
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 284
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 284
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 289
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 289
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 294
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 294
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 471
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 471
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 472
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 472
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 473
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 473
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 474
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 474
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 475
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 475
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 476
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 476
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 481
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 481
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 482
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 482
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 483
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 483
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 484
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 484
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 485
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 485
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 486
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 486
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 487
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 487
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 492
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 492
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 493
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 493
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 494
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 494
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 495
ERROR - 2021-05-10 03:51:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 495
ERROR - 2021-05-10 03:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:51:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:51:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:51:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:53:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:53:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:53:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:53:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:53:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:54:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-10 03:54:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:54:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-10 03:54:19 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:19 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:22 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:22 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:27 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:27 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:45 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:45 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:49 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:49 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:54:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:54:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:54:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:55:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:55:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:55:48 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:55:48 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 03:55:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:55:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:56:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:56:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:56:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 03:56:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 03:56:21 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 03:56:21 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 03:56:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:56:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:57:11 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-10 03:57:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:57:20 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-10 03:58:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 03:58:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 03:58:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:00:23 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:00:23 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:00:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:00:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:00:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:00:42 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:00:42 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:00:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:00:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:01:53 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:01:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:01:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:02:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:02:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:02:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:04:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:04:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:05:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:05:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:05:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:05:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:05:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:05:24 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:05:24 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:05:24 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:05:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:05:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:05:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:05:33 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:05:33 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:05:33 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:05:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:05:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:05:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:06:07 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-10 04:08:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:08:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:08:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:08:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:10:20 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:10:20 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:10:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:10:46 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:10:46 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:10:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:11:08 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:11:08 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 86
ERROR - 2021-05-10 04:11:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:11:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:11:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:11:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:11:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:11:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:13:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:13:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:13:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:17:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:17:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:19:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:20:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:20:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:21:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:21:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:22:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:22:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:22:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:24:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:24:26 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:24:26 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:24:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:24:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:25:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:25:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:25:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:25:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:27:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:28:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:28:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:31:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:31:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:36:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:36:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:37:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:37:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:38:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:38:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:39:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:39:00 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:39:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 509
ERROR - 2021-05-10 04:39:00 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 509
ERROR - 2021-05-10 04:39:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:39:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:39:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:39:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:40:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:40:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:40:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:41:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:41:06 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:41:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 509
ERROR - 2021-05-10 04:41:06 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 509
ERROR - 2021-05-10 04:41:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:41:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:41:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:42:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:42:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:42:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:42:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:44:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:44:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:44:30 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:44:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 509
ERROR - 2021-05-10 04:44:30 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 509
ERROR - 2021-05-10 04:44:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:44:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:44:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:44:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:44:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:45:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:45:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:45:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:46:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:46:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:51:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:51:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:52:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:52:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:52:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:52:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:52:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:52:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:53:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:53:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:54:14 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:54:14 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:54:14 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:54:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:54:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:54:23 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:54:23 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:54:23 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:54:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:54:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:54:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:54:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:54:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:54:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:54:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:54:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:55:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:55:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:55:19 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-10 04:55:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:55:28 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-10 04:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:55:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:56:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:56:00 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:56:00 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:56:00 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:56:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:56:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:56:44 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:56:44 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:56:44 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:56:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:56:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:56:54 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 04:56:54 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:56:54 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 04:56:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:56:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:58:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:58:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:58:31 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:58:31 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:58:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:58:40 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:58:40 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:58:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:16 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:59:16 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:59:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:27 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:59:27 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 04:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 04:59:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 04:59:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:00:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:01:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:01:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:01:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:02:26 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:02:26 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:03:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:06:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:06:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:06:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:07:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:07:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:08:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:08:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:10:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:11:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:11:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:12:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:12:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:12:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:13:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:13:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:13:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:13:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:14:06 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:14:06 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:14:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:14:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:14:22 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:14:22 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:14:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:14:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:17:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:17:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:17:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:17:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:17:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:17:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:17:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:17:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:17:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:23:18 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 87
ERROR - 2021-05-10 05:23:18 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 87
ERROR - 2021-05-10 05:23:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:23:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:23:53 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 87
ERROR - 2021-05-10 05:23:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 87
ERROR - 2021-05-10 05:23:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:23:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:24:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:24:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:26:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:26:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:27:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:27:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:28:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:28:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:28:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:29:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:29:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:29:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:29:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:31:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:32:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:32:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:33:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:33:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:33:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:34:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:34:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:34:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:34:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:35:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:35:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:35:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:35:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:35:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:35:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:36:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:36:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:36:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:36:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:36:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:36:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:36:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:36:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:37:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:37:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:37:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:39:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:39:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:40:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:40:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:41:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:41:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:42:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:42:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:45:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:45:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:45:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:46:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:46:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:46:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:47:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:51:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:51:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:51:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:51:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:52:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:54:05 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:54:05 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:54:27 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:54:27 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:54:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:54:45 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:54:45 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 78
ERROR - 2021-05-10 05:55:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:55:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:55:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 05:55:41 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 05:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:55:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:56:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:57:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:57:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:57:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 05:57:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 05:57:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 510
ERROR - 2021-05-10 05:57:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 510
ERROR - 2021-05-10 05:57:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:57:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:57:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:57:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 05:59:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 05:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:00:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:00:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:01:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:01:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:02:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:02:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:03:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:04:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:06:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:06:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:06:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:06:29 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:06:29 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:06:29 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:08:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:08:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:08:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:08:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:08:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 510
ERROR - 2021-05-10 06:08:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 510
ERROR - 2021-05-10 06:08:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:08:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:08:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:08:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:10:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:10:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:10:56 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:10:56 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:10:56 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:11:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:11:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:11:05 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:11:05 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:11:05 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:11:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:11:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:11:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:11:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:11:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:11:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:11:57 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 64
ERROR - 2021-05-10 06:11:57 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 64
ERROR - 2021-05-10 06:12:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:12:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:12:07 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 64
ERROR - 2021-05-10 06:12:07 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 64
ERROR - 2021-05-10 06:12:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:12:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:12:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:12:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:12:38 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 64
ERROR - 2021-05-10 06:12:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 64
ERROR - 2021-05-10 06:13:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:13:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:13:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:13:27 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:13:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:13:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:14:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:14:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:14:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:14:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:14:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:14:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:14:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:14:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:14:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:14:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:16:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:16:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:16:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:16:49 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:16:49 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:16:49 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:16:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:16:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:16:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:16:59 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 06:16:59 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:16:59 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 79
ERROR - 2021-05-10 06:16:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:19:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:19:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:19:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:19:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:19:41 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 06:19:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 06:19:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:19:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:19:53 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 06:19:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 06:19:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:19:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:01 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 06:20:01 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 06:20:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:20:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:22:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:22:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:22:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:22:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:23:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:23:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:26:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:26:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:26:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:26:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:27:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:27:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:27:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:28:28 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:28:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:28:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:29:28 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:29:28 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:29:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:30:41 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:30:41 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:30:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:30:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:31:27 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:31:27 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:31:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:31:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:32:26 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:32:26 --> Severity: Warning --> Attempt to read property "country_name" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 270
ERROR - 2021-05-10 06:32:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:32:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:33:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:33:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:33:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:33:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:33:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:33:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:33:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:34:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:34:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:34:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:34:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 06:34:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 06:34:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:00:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:01:05 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 07:01:05 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 07:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:01:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:01:37 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 07:01:37 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 63
ERROR - 2021-05-10 07:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:02:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:02:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 07:02:37 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-10 07:02:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:02:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:04:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:04:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:04:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:04:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:04:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:04:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:04:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:05:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:05:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:05:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:05:31 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:05:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:05:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:05:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:05:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:05:59 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:06:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:06:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:07:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:09:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:09:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:09:23 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:09:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:09:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:09:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:09:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:10:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:10:06 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 07:10:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:10:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:11:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:15:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:15:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:17:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:17:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:17:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:18:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:18:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:21:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:21:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:28:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:28:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:30:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:30:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:30:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:33:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:33:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:33:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:33:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:34:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:36:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:36:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:36:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:36:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:37:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:37:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:37:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:37:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:37:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:38:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:38:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:38:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:39:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:41:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:41:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:41:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:41:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:41:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:41:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:41:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:41:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:45:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:45:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:45:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:45:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:45:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:45:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:58:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 07:58:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 07:58:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:58:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:58:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 07:58:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 08:06:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:06:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:06:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:06:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:10:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:13:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:13:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:13:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:14:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:14:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:14:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:14:46 --> 404 Page Not Found: customer/Scripts/jquery-1.6.1.min.js
ERROR - 2021-05-10 08:14:46 --> 404 Page Not Found: customer/Scripts/jquery-ui-1.8.13.custom.min.js
ERROR - 2021-05-10 08:14:46 --> 404 Page Not Found: customer/Scripts/jquery.validate.min.js
ERROR - 2021-05-10 08:14:46 --> 404 Page Not Found: customer/Scripts/jquery.validate.wrapper.js
ERROR - 2021-05-10 08:14:47 --> 404 Page Not Found: customer/Scripts/jquery-1.6.1.min.js
ERROR - 2021-05-10 08:14:47 --> 404 Page Not Found: customer/Scripts/jquery-ui-1.8.13.custom.min.js
ERROR - 2021-05-10 08:14:47 --> 404 Page Not Found: customer/Scripts/jquery.validate.min.js
ERROR - 2021-05-10 08:14:47 --> 404 Page Not Found: customer/Scripts/jquery.validate.wrapper.js
ERROR - 2021-05-10 08:15:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:15:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:20:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:20:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:20:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 08:20:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 08:20:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 08:20:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 08:20:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-10 08:27:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:27:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:27:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:28:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:30:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:30:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:33:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:33:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:34:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:36:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:36:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:36:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:36:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:38:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:38:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:39:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:40:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:40:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:40:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:40:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:41:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:42:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:42:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:43:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:43:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:44:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:47:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:47:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:48:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:48:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:50:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:50:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:53:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:57:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:59:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 08:59:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 08:59:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:08:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:08:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:09:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:09:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:10:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:11:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:11:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:12:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:12:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:16:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:16:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:17:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:17:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:17:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:17:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:20:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:20:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:20:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:24:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:24:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:25:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:25:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:26:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:26:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:28:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:28:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:30:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:32:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:32:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:33:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:35:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:35:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:36:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:37:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:37:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:37:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:37:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:37:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:37:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:37:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:38:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:38:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:38:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:39:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:39:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:39:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:41:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:41:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:41:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:41:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:41:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:41:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:41:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:41:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:43:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:44:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:44:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:44:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:44:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:45:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:45:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:45:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:48:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:48:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:48:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:49:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:49:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:49:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:49:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:50:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:50:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:50:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:50:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:51:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:51:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:51:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:51:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:51:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:51:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:52:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:53:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:53:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:54:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:54:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:55:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:55:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:57:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:57:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:57:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:57:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:58:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:58:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 09:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 09:58:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:01:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:01:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:10:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:10:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:10:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:11:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:14:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:14:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:14:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:14:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:14:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:15:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:17:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:17:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:17:49 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:17:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:17:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:17:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:17:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:18:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:18:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:18:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:18:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:18:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:18:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:19:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:19:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:19:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:19:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:20:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:20:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:22:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:22:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:22:16 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:22:16 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:22:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:22:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:23:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:23:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:24:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:24:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:24:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:31:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:31:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:32:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:32:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:35:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:36:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:39:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:39:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:39:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:39:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:41:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:41:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:42:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:42:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:43:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:43:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:43:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:43:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:43:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:43:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:44:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:44:08 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:44:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:44:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:44:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:44:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:44:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:45:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:45:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:46:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:46:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:46:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:46:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:47:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:47:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:47:30 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-10 10:47:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:47:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:47:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:47:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:47:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:47:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:47:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:47:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:47:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:48:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:48:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:49:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:49:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:49:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:49:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:55:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:55:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:56:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:56:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:57:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:57:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:58:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 10:58:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 10:58:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 11:00:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-10 11:00:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 11:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-10 11:00:46 --> 404 Page Not Found: Assets/bootstrap
