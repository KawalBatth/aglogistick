<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 02:24:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'webnew' C:\xampp\htdocs\webfreight\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-03 02:24:32 --> Unable to connect to the database
ERROR - 2021-05-03 02:25:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:25:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:25:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:25:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:27:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:27:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:27:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:27:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:27:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:35:24 --> Query error: Table 'webfreight.customer_margin' doesn't exist - Invalid query: SELECT *
FROM `customer_margin`
WHERE `customer_id` = '10000001'
ERROR - 2021-05-03 02:36:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:36:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:36:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:36:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:36:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:36:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:36:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:36:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:37:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:37:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:37:09 --> 404 Page Not Found: admin/Users/script.js
ERROR - 2021-05-03 02:37:10 --> 404 Page Not Found: admin/Users/script.js
ERROR - 2021-05-03 02:38:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:00 --> 404 Page Not Found: admin/Users/script.js
ERROR - 2021-05-03 02:38:01 --> 404 Page Not Found: admin/Users/script.js
ERROR - 2021-05-03 02:38:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:09 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 47
ERROR - 2021-05-03 02:38:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:38:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:38:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:39:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:39:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:39:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:39:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:39:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:45:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:45:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 02:45:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:45:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 02:47:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 02:47:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 02:47:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 02:47:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 02:47:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:03:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:03:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:03:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:04:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:04:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:04:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:04:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:04:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:04:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:04:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:04:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:06:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:06:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:06:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:06:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:06:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:06:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:06:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:06:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:07:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:07:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:07:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:07:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:08:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:08:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:08:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:08:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:11:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:11:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:11:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:11:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:11:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:11:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:11:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:11:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:14:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:14:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:14:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:14:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:14:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:14:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:14:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:14:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:15:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:15:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:16:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:16:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:16:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:16:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:18:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:18:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:18:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:18:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:18:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:18:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:18:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:18:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:18:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 03:18:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 03:20:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:20:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:20:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:20:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:20:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:20:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:20:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:20:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:44 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 508
ERROR - 2021-05-03 03:38:45 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 509
ERROR - 2021-05-03 03:41:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:41:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:41:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:41:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:41:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:41:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 03:44:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:44:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 03:44:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 03:44:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:11:45 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 273
ERROR - 2021-05-03 04:11:53 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 273
ERROR - 2021-05-03 04:16:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:16:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-03 04:17:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:17:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:17:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:17:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:17:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:17:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:17:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:17:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:17:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:17:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:17:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:17:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:21:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:21:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:21:17 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4091
ERROR - 2021-05-03 04:21:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:21:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:25:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:25:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:25:33 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4091
ERROR - 2021-05-03 04:25:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:25:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:26:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:26:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:26:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:26:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:26:06 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 179
ERROR - 2021-05-03 04:26:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:26:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:26:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:26:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:26:47 --> Severity: error --> Exception: Too few arguments to function Auth_model::get_margin(), 0 passed in C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php on line 179 and exactly 1 expected C:\xampp\htdocs\webfreight\application\models\admin\Auth_model.php 197
ERROR - 2021-05-03 04:27:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:27:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:27:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:27:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:27:32 --> Severity: error --> Exception: Too few arguments to function Auth_model::get_margin(), 0 passed in C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php on line 179 and exactly 1 expected C:\xampp\htdocs\webfreight\application\models\admin\Auth_model.php 197
ERROR - 2021-05-03 04:27:46 --> Severity: error --> Exception: Too few arguments to function Auth_model::get_margin(), 0 passed in C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php on line 179 and exactly 1 expected C:\xampp\htdocs\webfreight\application\models\admin\Auth_model.php 197
ERROR - 2021-05-03 04:28:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:28:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:28:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:28:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:29:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:29:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:29:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:29:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:29:28 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 179
ERROR - 2021-05-03 04:30:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:30:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:30:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:30:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:30:58 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 179
ERROR - 2021-05-03 04:31:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:31:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:31:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:31:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:31:41 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 179
ERROR - 2021-05-03 04:32:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:32:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:32:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:32:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:32:04 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 179
ERROR - 2021-05-03 04:32:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:32:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:32:27 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:32:27 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:32:30 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 179
ERROR - 2021-05-03 04:32:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:32:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:32:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:32:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:34:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:34:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:34:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:34:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:40:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:40:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:40:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:40:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:41:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:41:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:41:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:41:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:42:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:42:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:42:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:42:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:43:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:43:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:43:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:43:10 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:45:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:45:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:46:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 04:46:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:46:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:46:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:46:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:46:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:47:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:47:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:47:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:47:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:47:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:47:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:47:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:47:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:48:01 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 395
ERROR - 2021-05-03 04:48:01 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `customer_margin` (`customer_id`, `origin`, `margin_rate`) VALUES (NULL, NULL, '[]')
ERROR - 2021-05-03 04:48:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:48:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:48:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:48:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:48:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:48:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:49:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:49:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:49:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:49:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:49:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:49:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:49:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:49:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:51:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:51:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:51:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:51:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:53:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:53:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:53:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:53:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:54:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:54:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:54:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:54:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:54:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:54:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:58:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:58:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:58:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:58:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:59:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:59:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:59:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:59:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:59:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:59:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:59:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:59:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:59:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:59:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 04:59:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 04:59:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:00:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:00:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:00:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:00:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:00:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:00:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:00:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:00:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:00:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:00:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:00:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:00:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:01:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:01:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:01:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:01:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:01:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:01:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:01:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:01:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:01:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:01:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:01:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:01:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:06:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:06:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:06:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:06:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:07:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:07:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:08:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:08:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:08:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:08:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:09:03 --> Query error: Column 'is_dangerous' cannot be null - Invalid query: INSERT INTO `surcharges_list` (`carrier_id`, `surcharge_name`, `surcharge_price`, `surcharge_type`, `is_dangerous`, `last_modified`) VALUES ('15', 'FUEL', '4343', '0', NULL, '2021/05/03 05:09:03')
ERROR - 2021-05-03 05:09:41 --> Query error: Column 'surcharge_type' cannot be null - Invalid query: INSERT INTO `surcharges_list` (`carrier_id`, `surcharge_name`, `surcharge_price`, `surcharge_type`, `is_dangerous`, `last_modified`) VALUES (NULL, NULL, NULL, NULL, NULL, '2021/05/03 05:09:41')
ERROR - 2021-05-03 05:09:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:09:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:09:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:09:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:09:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:09:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:10:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:10:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:10:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:10:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:10:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:10:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:10:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:10:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:10:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:10:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:10:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:10:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:11:11 --> Severity: error --> Exception: Call to undefined function pg_query() C:\xampp\htdocs\webfreight\application\controllers\admin\Rates.php 49
ERROR - 2021-05-03 05:11:12 --> Severity: error --> Exception: Call to undefined function pg_query() C:\xampp\htdocs\webfreight\application\controllers\admin\Rates.php 49
ERROR - 2021-05-03 05:11:17 --> Severity: error --> Exception: Call to undefined function pg_query() C:\xampp\htdocs\webfreight\application\controllers\admin\Rates.php 49
ERROR - 2021-05-03 05:11:47 --> Severity: error --> Exception: Call to undefined function pg_query() C:\xampp\htdocs\webfreight\application\controllers\admin\Rates.php 49
ERROR - 2021-05-03 05:11:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:11:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:11:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:11:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:11:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:11:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:11:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:11:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:11:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:11:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:12:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:12:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:12:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:12:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:16:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:16:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:16:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:16:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:21:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:21:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:21:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:21:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:21:38 --> 404 Page Not Found: admin/Rate_sheet_export_to_htmlix/index
ERROR - 2021-05-03 05:22:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:22:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:22:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:22:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:23:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:23:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:23:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:23:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:30:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:30:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:30:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:30:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:32:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:32:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:32:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:32:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:35:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:35:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:35:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:35:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:36:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:36:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:36:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:36:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:36:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 395
ERROR - 2021-05-03 05:36:40 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `customer_margin` (`customer_id`, `origin`, `margin_rate`) VALUES (NULL, 'A10', '[]')
ERROR - 2021-05-03 05:36:56 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 414
ERROR - 2021-05-03 05:36:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 414
ERROR - 2021-05-03 05:36:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:36:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:36:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: select * from customer where customer_id=
ERROR - 2021-05-03 05:36:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 05:36:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-03 05:37:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:37:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:37:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:37:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:37:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 05:37:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:37:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 05:39:09 --> 404 Page Not Found: admin/Address_book_import/index
ERROR - 2021-05-03 06:12:04 --> 404 Page Not Found: customer/Customers/import_excel
ERROR - 2021-05-03 06:51:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:51:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:52:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Member C:\xampp\htdocs\webfreight\system\core\Loader.php 344
ERROR - 2021-05-03 06:53:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:53:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:53:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:53:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:53:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Member_model C:\xampp\htdocs\webfreight\system\core\Loader.php 344
ERROR - 2021-05-03 06:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:56:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:56:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:56:48 --> Severity: error --> Exception: C:\xampp\htdocs\webfreight\application\models/admin/Member_model.php exists, but doesn't declare class Member_model C:\xampp\htdocs\webfreight\system\core\Loader.php 336
ERROR - 2021-05-03 06:57:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:57:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:57:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:57:52 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 06:57:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 06:57:52 --> Severity: Warning --> Undefined array key "Status" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 06:57:52 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 75
ERROR - 2021-05-03 06:57:52 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `members` (`name`, `email`, `phone`, `status`, `created`, `modified`) VALUES ('kawal', NULL, NULL, NULL, '2021-05-03 06:57:52', '2021-05-03 06:57:52')
ERROR - 2021-05-03 06:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:59:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:59:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 06:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 06:59:22 --> Severity: Warning --> Undefined array key "Name" C:\xampp\htdocs\webfreight\application\controllers\Members.php 66
ERROR - 2021-05-03 06:59:22 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 06:59:22 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 06:59:22 --> Severity: Warning --> Undefined array key "Status" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 06:59:22 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 75
ERROR - 2021-05-03 06:59:22 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `members` (`name`, `email`, `phone`, `status`, `created`, `modified`) VALUES (NULL, NULL, NULL, NULL, '2021-05-03 06:59:22', '2021-05-03 06:59:22')
ERROR - 2021-05-03 07:00:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:00:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:13:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:13:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:14:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 07:16:47 --> Query error: Unknown column 'modified' in 'field list' - Invalid query: UPDATE `address_book` SET `contact_name` = 'MARK CANNING', `company_name` = 'CENTURION GARAGE DOORS', `state` = 'QLD', `postcode` = '4207', `address` = '145 QUINNS HILL ROAD EAST', `address1` = '', `phone` = '0734414900', `city` = 'STAPYLTON', `email` = '', `country` = 'Australia', `department` = NULL, `deafult_billing_type` = NULL, `fax` = NULL, `account_number` = NULL, `residential_address` = NULL, `default_service_type` = NULL, `default_package_type` = NULL, `modified` = '2021-05-03 07:16:47'
WHERE `email` = ''
ERROR - 2021-05-03 07:16:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-05-03 07:20:29 --> Query error: Unknown column 'modified' in 'field list' - Invalid query: UPDATE `address_book` SET `contact_name` = 'MARK CANNING', `company_name` = 'CENTURION GARAGE DOORS', `state` = 'QLD', `postcode` = '4207', `address` = '145 QUINNS HILL ROAD EAST', `address1` = '', `phone` = '734414900', `city` = 'STAPYLTON', `email` = '', `country` = 'Australia', `department` = '', `deafult_billing_type` = '', `fax` = '', `account_number` = '', `residential_address` = '', `default_service_type` = '', `default_package_type` = '', `modified` = '2021-05-03 07:20:29'
WHERE `email` = ''
ERROR - 2021-05-03 07:24:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:24:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:24:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:24:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:34:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:34:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:34:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:43:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:43:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:45:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:45:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:55:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:55:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:55:37 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `address_book`
WHERE `email` = ''
ERROR - 2021-05-03 07:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:57:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:57:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 07:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:14 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 59
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 60
ERROR - 2021-05-03 07:57:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\webfreight\application\views\customers\import_excel.php 62
ERROR - 2021-05-03 07:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 07:57:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:01:46 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:01:46 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `address_book`
WHERE `email` IS NULL
ERROR - 2021-05-03 08:03:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:03:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:03:32 --> Severity: Warning --> Undefined variable $prevCount C:\xampp\htdocs\webfreight\application\controllers\Members.php 96
ERROR - 2021-05-03 08:03:32 --> Query error: Unknown column 'created' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `state`, `postcode`, `address`, `address1`, `phone`, `city`, `country`, `department`, `deafult_billing_type`, `fax`, `account_number`, `residential_address`, `default_service_type`, `default_package_type`, `created`, `modified`) VALUES ('MARK CANNING', 'CENTURION GARAGE DOORS', 'QLD', '4207', '145 QUINNS HILL ROAD EAST', '', '0734414900', 'STAPYLTON', 'Australia', '', '', '', '', '', '', '', '2021-05-03 08:03:32', '2021-05-03 08:03:32')
ERROR - 2021-05-03 08:04:23 --> Severity: Warning --> Undefined array key "contact_name" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:04:23 --> Query error: Unknown column 'created' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `state`, `postcode`, `address`, `address1`, `phone`, `city`, `country`, `department`, `deafult_billing_type`, `fax`, `account_number`, `residential_address`, `default_service_type`, `default_package_type`, `created`, `modified`) VALUES ('MARK CANNING', 'CENTURION GARAGE DOORS', 'QLD', '4207', '145 QUINNS HILL ROAD EAST', '', '0734414900', 'STAPYLTON', 'Australia', '', '', '', '', '', '', '', '2021-05-03 08:04:23', '2021-05-03 08:04:23')
ERROR - 2021-05-03 08:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:04:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:04:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:04:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:04:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:05:09 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `address_book`
WHERE `email` = 'MARK CANNING'
ERROR - 2021-05-03 08:06:11 --> Query error: Unknown column 'modified' in 'field list' - Invalid query: UPDATE `address_book` SET `contact_name` = 'MARK CANNING', `company_name` = 'CENTURION GARAGE DOORS', `state` = 'QLD', `postcode` = '4207', `address` = '145 QUINNS HILL ROAD EAST', `address1` = '', `phone` = '0734414900', `city` = 'STAPYLTON', `country` = 'Australia', `department` = '', `deafult_billing_type` = '', `fax` = '', `account_number` = '', `residential_address` = '', `default_service_type` = '', `default_package_type` = '', `modified` = '2021-05-03 08:06:11'
WHERE `contact_name` = 'MARK CANNING'
ERROR - 2021-05-03 08:07:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:07:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:07:38 --> Query error: Unknown column 'created' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `state`, `postcode`, `address`, `address1`, `phone`, `city`, `country`, `department`, `deafult_billing_type`, `fax`, `account_number`, `residential_address`, `default_service_type`, `default_package_type`, `created`, `modified`) VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2021-05-03 08:07:38', '2021-05-03 08:07:38')
ERROR - 2021-05-03 08:08:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:08:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:08:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:08:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:08:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:08:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:11:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:11:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:12:16 --> 404 Page Not Found: Customers/import_excel
ERROR - 2021-05-03 08:12:21 --> 404 Page Not Found: Customers/import_excel
ERROR - 2021-05-03 08:12:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:12:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:12:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:12:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:13:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:13:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:13:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:13:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:39:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:39:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:39:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:39:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:52 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:53 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:39:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\helpers\url_helper.php 564
ERROR - 2021-05-03 08:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:41:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:41:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:47:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:47:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:55 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:56 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 90
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 98
ERROR - 2021-05-03 08:47:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\helpers\url_helper.php 564
ERROR - 2021-05-03 08:52:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:52:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:52:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:52:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:52:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:52:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:53:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:53:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:54:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:54:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:54:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:54:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:54:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:54:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:54:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:54:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:55:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:55:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:55:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:56:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:56:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:56:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:57:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:58:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 08:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 08:58:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:01:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:02:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:02:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:02:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:02:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:09:50 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `temp_data` (`user_id`, `formdata`) VALUES (NULL, 'customerCode=&shipmentPage.senderAddress.companyName=TIELINE RESEARCH&shipmentPage.senderAddress.phone=0894132000&shipmentPage.senderAddress.contactName=LISSA BEAUFOND&shipmentPage.senderAddress.email=beaufond@tieline.com.au&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=4 BENDSTEN PLACE              &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=BALCATTA&shipmentPage.senderAddress.postalCode=6021&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=0&shipmentPage.receiverAddress.address=&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-05-03&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=1&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[0].addConName=Dangerous Goods&shipmentPage.addCons[0].addConCode=dangerousgoods&shipmentPage.addCons[0].listProperties[0].addConDetailName=UN Number (4Digits)&shipmentPage.addCons[0].listProperties[0].addConDetailCode=unnumber&shipmentPage.addCons[0].listProperties[0].value=&shipmentPage.addCons[0].listProperties[1].addConDetailName=Packing Group&shipmentPage.addCons[0].listProperties[1].addConDetailCode=packinggroup&shipmentPage.addCons[0].listProperties[1].value=1&shipmentPage.addCons[0].listProperties[2].addConDetailName=I have a MSDS(Material Safety Data Sheet). Dangerous Goods attracts an additional surcharge.&shipmentPage.addCons[0].listProperties[2].addConDetailCode=msda&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=&shipmentPage.addCons[2].value=0&shipmentPage.addCons[2].addConName=agl Warranty&shipmentPage.addCons[2].addConCode=aglWarranty')
ERROR - 2021-05-03 09:41:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:41:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:42:01 --> Query error: Unknown column 'email' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('test', 'gfg', 'gfg', 'gfgf', 'gfgfgfg', 'gfg', 'fgfg', 'gfgfg', 'fgfg', 'Australia', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-03 09:42:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:42:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:42:15 --> Query error: Unknown column 'email' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-03 09:42:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:42:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:43:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:43:42 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('6676767', '6767', '7676', '7676', '76767', '767', '767', '676767', '76767676', '4', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-03 09:44:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:44:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:44:33 --> 404 Page Not Found: customer/Customer/add_address_book
ERROR - 2021-05-03 09:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:44:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:45:01 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-03 09:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:46:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:46:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:46:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:46:40 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-03 09:47:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:47:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:47:20 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('kawal', '656566', '54545', '', 'Melbourne', 'VIC', '3000', '65656', 'KAWALBATTH@GMAIL.COM', '0', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-03 09:47:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:47:49 --> 404 Page Not Found: customer/Customer/add_address_book
ERROR - 2021-05-03 09:48:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:48:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:49:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:49:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:49:15 --> 404 Page Not Found: customer/Customer/add_address_book
ERROR - 2021-05-03 09:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:50:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:50:30 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('565656', '5656', '6565', '5656', '656565', '5656', '6565', '6565656', 'KAWALBATTH@GMAIL.COM', '4', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-03 09:51:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:51:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:51:49 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-03 09:52:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:52:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:52:39 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-03 09:53:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:53:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:53:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:53:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:53:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:53:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:53:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:53:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:53:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:53:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:54:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:54:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 09:54:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:54:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 09:54:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:54:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:54:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:55:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:55:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:55:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 09:56:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 09:56:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:01:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:01:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:02:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:04:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:04:39 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('67676', '7676', '6767', '7676', '7676', '7676', '767', '7676', 'KAWALBATTH@GMAIL.COM', '2', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-03 10:05:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:05:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:05:37 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('5656565', '656566', '65656', '', 'Melbourne', 'VIC', '3000', '565', 'KAWALBATTH@GMAIL.COM', '0', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-03 10:05:55 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('5656565', '656566', '65656', '545454', 'Melbourne', 'VIC', '3000', '565', 'KAWALBATTH@GMAIL.COM', '0', '5454', '54545', '1', '1', '0', '454545454', '1')
ERROR - 2021-05-03 10:07:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:07:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 10:07:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 10:07:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 10:07:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 10:07:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 10:07:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 10:07:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 10:07:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 10:07:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 10:07:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-03 10:07:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 10:07:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-03 10:08:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:08:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:15:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:15:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:16:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:16:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:16:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:21:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:21:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:29:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:32:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:32:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:33:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:33:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:34:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:34:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-03 10:34:27 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-03 10:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:34:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:35:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:38:16 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:39:01 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:40:59 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:41:35 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:42:37 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:44:36 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:44:56 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:50:28 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\system\database\DB_query_builder.php 683
ERROR - 2021-05-03 10:51:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:51:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:51:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:51:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:52:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:52:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:53:55 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 518
ERROR - 2021-05-03 10:53:55 --> Severity: Warning --> Attempt to read property "customer_id" on array C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 519
ERROR - 2021-05-03 10:53:55 --> Severity: Warning --> Attempt to read property "contact_name" on array C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 520
ERROR - 2021-05-03 10:53:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:53:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:54:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:54:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-03 10:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-03 10:57:05 --> 404 Page Not Found: Assets/bootstrap
