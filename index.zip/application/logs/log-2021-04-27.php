<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-27 02:25:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:25:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:25:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 02:25:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:25:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:25:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 02:25:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:25:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:25:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 02:25:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 02:28:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:28:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 02:28:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 02:28:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 02:34:35 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 02:35:39 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 02:41:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 02:46:20 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 02:50:18 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 02:50:29 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 02:51:26 --> Query error: Table 'webfreight.quote' doesn't exist - Invalid query: SELECT *
FROM `quote`
ERROR - 2021-04-27 02:52:26 --> Query error: Table 'webfreight.address_book' doesn't exist - Invalid query: SELECT *
FROM `address_book`
ERROR - 2021-04-27 02:53:36 --> Severity: Warning --> Undefined variable $quote C:\xampp\htdocs\webfreight\application\views\customers\quote.php 260
ERROR - 2021-04-27 02:53:36 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\quote.php 260
ERROR - 2021-04-27 02:53:45 --> Query error: Column 'contact_name' cannot be null - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 02:54:12 --> Query error: Column 'contact_name' cannot be null - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 02:54:16 --> Severity: Warning --> Undefined variable $quote C:\xampp\htdocs\webfreight\application\views\customers\quote.php 260
ERROR - 2021-04-27 02:54:16 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\quote.php 260
ERROR - 2021-04-27 02:58:08 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-04-27 03:02:01 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-04-27 03:04:17 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-04-27 03:16:16 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 511
ERROR - 2021-04-27 03:16:16 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 511
ERROR - 2021-04-27 03:16:27 --> Query error: Column 'contact_name' cannot be null - Invalid query: INSERT INTO `address_book` (`contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 03:18:13 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 511
ERROR - 2021-04-27 03:18:13 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 511
ERROR - 2021-04-27 03:19:25 --> 404 Page Not Found: customer/Customer/add_address_book
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 259
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 260
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 261
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 262
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 263
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 265
ERROR - 2021-04-27 03:36:06 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 266
ERROR - 2021-04-27 03:36:07 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 259
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 260
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 261
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 262
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 263
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 265
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 266
ERROR - 2021-04-27 03:36:08 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 03:36:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-27 03:36:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-27 03:36:23 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-27 03:36:23 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-27 03:36:23 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 259
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 260
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 261
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 262
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 263
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 265
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 266
ERROR - 2021-04-27 03:36:54 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 03:37:27 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 03:38:33 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 03:51:35 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 03:51:43 --> 404 Page Not Found: customer/Customers/add_new_booking
ERROR - 2021-04-27 03:54:52 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 245
ERROR - 2021-04-27 04:20:56 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:25:48 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:25:51 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:26:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:26:18 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:27:47 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:27:49 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:27:58 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:29:05 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:29:06 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:30:15 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:30:24 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 04:30:24 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 04:30:24 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:30:56 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 04:30:56 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 04:30:56 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:33:39 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 04:33:57 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:40:56 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:41:05 --> Query error: Column 'content_desc' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES ('10000002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:41:39 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:41:51 --> Query error: Column 'content_desc' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES ('10000002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:42:22 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:42:52 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:43:34 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:43:45 --> Query error: Column 'content_desc' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES ('10000002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:46:47 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:46:59 --> 404 Page Not Found: customer/Add_new_booking/index
ERROR - 2021-04-27 04:47:09 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:47:23 --> 404 Page Not Found: customer/Add_new_booking/index
ERROR - 2021-04-27 04:48:04 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:48:13 --> Query error: Column 'content_desc' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES ('10000002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 04:48:37 --> 404 Page Not Found: Customers/add_new_booking
ERROR - 2021-04-27 04:48:42 --> 404 Page Not Found: Customersadd_new_booking/index
ERROR - 2021-04-27 04:48:48 --> 404 Page Not Found: customer/Add_new_booking/index
ERROR - 2021-04-27 04:49:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:50:32 --> 404 Page Not Found: customer/Customers/booking
ERROR - 2021-04-27 04:50:39 --> 404 Page Not Found: Customers/booking
ERROR - 2021-04-27 04:50:47 --> 404 Page Not Found: customer/Customers/booking
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 04:51:46 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 04:52:07 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, '6767', '767', '667', '767', '1', '<div style=', '<div style=', '<div style=', 'T', '<div style=', '<div style=', '<div style=', '<div style=', '2021-04-27', '11:00:00', '17:30:00', '1', '1', 'Front Desk')
ERROR - 2021-04-27 04:54:31 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 04:54:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:15:24 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:15:48 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:15:49 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:17:30 --> 404 Page Not Found: customer/Customers/booking
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1772
ERROR - 2021-04-27 05:18:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1772
ERROR - 2021-04-27 05:20:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:20:33 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:20:43 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:21:15 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:21:41 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:22:10 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:22:29 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:23:01 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:24:20 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:24:30 --> 404 Page Not Found: customer/Save_booking/index
ERROR - 2021-04-27 05:25:00 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:25:06 --> 404 Page Not Found: customer/Save_booking/index
ERROR - 2021-04-27 05:25:11 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:25:15 --> 404 Page Not Found: customer/Save_booking/index
ERROR - 2021-04-27 05:25:51 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:25:56 --> 404 Page Not Found: Customers/save_booking
ERROR - 2021-04-27 05:26:06 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:26:15 --> 404 Page Not Found: Customers/save_booking
ERROR - 2021-04-27 05:27:07 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:27:17 --> 404 Page Not Found: customer/Customer/save_booking
ERROR - 2021-04-27 05:28:58 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:29:07 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, '88', '89', '989', '989', '1', 'Kawaljit', 'Batth', '49 a Arkana  ', 'T', 'Perth', '0846573646', '6105', 'SA', '2021-04-27', '11:30:00', '17:30:00', '1', '1', 'Front Desk')
ERROR - 2021-04-27 05:30:07 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:30:10 --> 404 Page Not Found: customer/Customer/add_new_booking
ERROR - 2021-04-27 05:31:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:31:25 --> 404 Page Not Found: customer/Customer/add_new_booking
ERROR - 2021-04-27 05:31:50 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:32:08 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:32:12 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, '', '', '', '', '0', 'Kawaljit', 'Batth', '49 a Arkana  ', 'T', 'Perth', '0846573646', '6105', 'SA', '2021-04-27', '12:00:00', '17:30:00', '1', '1', 'Front Desk')
ERROR - 2021-04-27 05:32:33 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:32:50 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:33:02 --> 404 Page Not Found: customer/Customer/add_new_booking
ERROR - 2021-04-27 05:33:20 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:33:39 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:34:26 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:34:44 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:36:03 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:36:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:36:42 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:36:49 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:37:25 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:37:26 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:37:29 --> 404 Page Not Found: customer/Add_new_booking/index
ERROR - 2021-04-27 05:37:40 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:37:59 --> 404 Page Not Found: customer/Add_new_booking/index
ERROR - 2021-04-27 05:39:17 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:39:33 --> 404 Page Not Found: customer/Add_new_booking/index
ERROR - 2021-04-27 05:40:09 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:40:13 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-04-27 05:40:29 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:41:33 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:43:19 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:43:29 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`) VALUES (NULL, '545', '545', '545', '5454', '1', 'Kawaljit', 'Batth', '49 a Arkana  ', 'T', 'Perth', '0846573646', '6105', 'SA', '2021-04-27', '12:00:00', '17:30:00', '1', '1', 'Front Desk')
ERROR - 2021-04-27 05:43:55 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:44:56 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:45:45 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:45:46 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:46:51 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 05:56:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 05:56:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 05:56:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 05:56:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:00:18 --> Query error: Unknown column 'image' in 'field list' - Invalid query: INSERT INTO `customer` (`customer_id`, `customerName`, `contact_name`, `contact_title`, `address`, `city`, `country`, `postal_code`, `state_code`, `phone`, `fax`, `email`, `mobile`, `alt_contact`, `billing_customer_name`, `billing_contact_name`, `billing_contact_title`, `billing_address`, `billing_address2`, `billing_city`, `billing_country`, `billing_postal_code`, `billing_state_code`, `billing_phone`, `billing_fax`, `billing_email`, `billing_mobile`, `billing_alt_contact`, `owner`, `other_phone`, `other_email`, `other_contact`, `other_phone1`, `other_email1`, `other_contact1`, `other_phone2`, `other_email2`, `other_contact2`, `other_phone3`, `other_email3`, `notes`, `image`, `margin`) VALUES ('10000005', 'TEST', 'TEST', '', '556565 ', '65', '12', '', '', '5656565656', '', 'kawalbatth89@gmail.com', '', '', 'TEST', 'TEST', '', '556565', '', '65', '12', '', '', '5656565656', '', 'kawalbatth89@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '00.00')
ERROR - 2021-04-27 06:00:33 --> Query error: Unknown column 'image' in 'field list' - Invalid query: INSERT INTO `customer` (`customer_id`, `customerName`, `contact_name`, `contact_title`, `address`, `city`, `country`, `postal_code`, `state_code`, `phone`, `fax`, `email`, `mobile`, `alt_contact`, `billing_customer_name`, `billing_contact_name`, `billing_contact_title`, `billing_address`, `billing_address2`, `billing_city`, `billing_country`, `billing_postal_code`, `billing_state_code`, `billing_phone`, `billing_fax`, `billing_email`, `billing_mobile`, `billing_alt_contact`, `owner`, `other_phone`, `other_email`, `other_contact`, `other_phone1`, `other_email1`, `other_contact1`, `other_phone2`, `other_email2`, `other_contact2`, `other_phone3`, `other_email3`, `notes`, `image`, `margin`) VALUES ('10000005', 'TEST', 'TEST', '', '556565 ', '65', '12', '', '', '5656565656', '', 'kawalbatth89@gmail.com', '', '', 'TEST', 'TEST', '', '556565', '', '65', '12', '', '', '5656565656', '', 'kawalbatth89@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '00.00')
ERROR - 2021-04-27 06:01:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:01:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:01:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:01:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:03:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:03:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:03:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:03:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:05:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:05:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:05:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:05:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:05:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:05:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:05:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:05:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:06:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:06:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:06:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:06:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:13:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:13:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:13:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:13:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:13:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:13:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:13:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:13:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:15:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:15:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:15:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:15:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:15:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:15:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 06:15:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:15:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 06:16:03 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 06:20:12 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 06:21:38 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 06:21:57 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 06:21:59 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 06:24:28 --> 404 Page Not Found: customer/Customers/booking
ERROR - 2021-04-27 06:24:35 --> 404 Page Not Found: Customers/booking
ERROR - 2021-04-27 06:27:37 --> 404 Page Not Found: Customers/booking
ERROR - 2021-04-27 06:27:39 --> 404 Page Not Found: Customers/booking
ERROR - 2021-04-27 06:27:41 --> 404 Page Not Found: Customers/booking
ERROR - 2021-04-27 06:29:06 --> 404 Page Not Found: Customers/booking
ERROR - 2021-04-27 06:29:46 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 06:29:57 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:15:29 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 07:15:38 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 07:15:48 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:24:04 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:24:31 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:24:34 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:25:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:26:13 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $surcharge C:\xampp\htdocs\webfreight\application\views\customers\booking.php 4
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 59
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1209
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1323
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1324
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1325
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1326
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1328
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1329
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1440
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1445
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1450
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1460
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1468
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1473
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 07:26:22 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1478
ERROR - 2021-04-27 07:26:23 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:27:24 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:33:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 07:33:49 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 07:33:49 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 07:34:04 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:37:58 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:45:09 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:46:17 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:46:53 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 07:50:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 08:02:15 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 08:57:26 --> 404 Page Not Found: Customers/address_book
ERROR - 2021-04-27 09:19:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 09:19:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-27 09:19:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 09:19:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-27 09:46:40 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 09:46:47 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 09:50:00 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 09:50:44 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 09:57:37 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 10:04:02 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 250
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:07:42 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:07:42 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:09:45 --> Query error: Column 'quote_number' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`) VALUES ('2021-04-27', '10000002', 'Kawaljit', NULL, 'Perth', '6000', 'Melbourne', '3000', 'Overnight', 'Customer packaging', '33.00')
ERROR - 2021-04-27 10:10:13 --> Query error: Column 'quote_number' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`) VALUES ('2021-04-27', '10000002', 'Kawaljit', NULL, 'Perth', '6000', 'Melbourne', '3000', 'Overnight', 'Customer packaging', '33.00')
ERROR - 2021-04-27 10:10:18 --> Query error: Column 'quote_number' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`) VALUES ('2021-04-27', '10000002', 'Kawaljit', NULL, 'Perth', '6000', 'Melbourne', '3000', 'Overnight', 'Customer packaging', '33.00')
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:10:42 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:10:42 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:10:45 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:10:45 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:14:04 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:14:04 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:14:25 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:14:25 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:14:28 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:14:28 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:15:02 --> Query error: Column 'quote_number' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`) VALUES ('2021-04-27', '10000002', 'Kawaljit', NULL, 'Perth', '6000', 'Melbourne', '3000', 'Overnight', 'Customer packaging', '3.00')
ERROR - 2021-04-27 10:15:19 --> Query error: Column 'quote_number' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`) VALUES ('2021-04-27', '10000002', 'Kawaljit', NULL, 'Perth', '6000', 'Melbourne', '3000', 'Overnight', 'Customer packaging', '3.00')
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:15:37 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:15:37 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:16:19 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:16:19 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:16:21 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:16:21 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:29:07 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:29:07 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:29:09 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:29:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:29:51 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:29:51 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:32:11 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:32:11 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:34:53 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:34:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:39:33 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:39:33 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:45:56 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:45:56 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:45:59 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:45:59 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:46:50 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:46:50 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:48:13 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:48:13 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:49:53 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:49:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:51:08 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:51:08 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:51:43 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:51:43 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:52:25 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:52:25 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:53:20 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:53:20 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:54:14 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:54:14 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:54:23 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:54:23 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:54:46 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:54:46 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-27 10:55:09 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-27 10:55:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
