<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-11 02:31:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 02:31:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 02:31:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 02:31:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 02:31:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 02:31:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 02:31:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 02:31:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 02:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:31:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:32:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:35:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:35:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:35:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:37:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:37:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:40:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:41:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:41:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:42:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 02:42:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 02:43:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:25:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:25:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:26:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:30:05 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 499
ERROR - 2021-05-11 03:30:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:30:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:30:27 --> Query error: Unknown column 'carrier_id' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000035', '<div style=', '545454', '54545', '45454', '545454545', '1', 'JOBAN', 'BATTH', '54545  ', 'T', 'MELBOURNE', '45555454', '3000', 'VIC', '2021-05-11', '09:30:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"},{\"message\":\"One or more shipments have a cubic weight more than 4 times greater than dead weight\"}],\"shipments\":[{\"shipment_id\":\"vyYK0EqXr40AAAF5wPgdllkL\",\"shipment_reference\":\"54545\",\"shipment_creation_date\":\"2021-05-11T11:30:27+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":43.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"VPIK0EqXUEMAAAF5wfgdllkL\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001373FPP00001\",\"consignment_id\":\"111Z50001373\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":168430.41,\"total_cost_ex_gst\":153118.55,\"shipping_cost\":153118.55,\"total_gst\":15311.86,\"freight_charge\":153118.55,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T11:30:27+10:00\"}]}')
ERROR - 2021-05-11 03:30:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:30:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:30:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:30:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:32:20 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 499
ERROR - 2021-05-11 03:32:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:32:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:32:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:32:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:32:55 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 499
ERROR - 2021-05-11 03:32:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:32:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:33:23 --> Query error: Unknown column 'carrier_id' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000035', '<div style=', '5656', '6565', '656565', '656565656', '1', 'JOBAN', 'BATTH', '54545  ', 'T', 'MELBOURNE', '45555454', '3000', 'VIC', '2021-05-11', '10:00:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"gawK0EapzOcAAAF5LagdiVkO\",\"shipment_reference\":\"6565\",\"shipment_creation_date\":\"2021-05-11T11:33:23+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":66.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"U7oK0Eap3oAAAAF5L6gdiVkO\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001374FPP00001\",\"consignment_id\":\"111Z50001374\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":599.78,\"total_cost_ex_gst\":545.25,\"shipping_cost\":545.25,\"total_gst\":54.53,\"freight_charge\":545.25,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T11:33:23+10:00\"}]}')
ERROR - 2021-05-11 03:33:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:33:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:37:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:37:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:38:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:38:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:39:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:39:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:39:21 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000035', '11', 'rrr', '54545454', 'eerererere', 'f4333434334', '1', 'JOBAN', 'BATTH', '54545  ', 'T', 'MELBOURNE', '45555454', '3000', 'VIC', '2021-05-11', '10:00:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"YqgK0EqXet4AAAF5WyAdllkU\",\"shipment_reference\":\"54545454\",\"shipment_creation_date\":\"2021-05-11T11:39:21+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":40.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"mE4K0EqXVsMAAAF5XSAdllkU\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001376FPP00001\",\"consignment_id\":\"111Z50001376\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":1092.30,\"total_cost_ex_gst\":993.00,\"shipping_cost\":993.00,\"total_gst\":99.30,\"freight_charge\":993.00,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T11:39:21+10:00\"}]}')
ERROR - 2021-05-11 03:39:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:39:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:39:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:40:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:41:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:41:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:41:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:41:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:42:10 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-11 03:42:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:42:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:42:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:43:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:43:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:43:39 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000035', '11', '44545454', '545454', 'ererere', '554545454', '1', 'JOBAN', 'BATTH', '54545  ', 'T', 'MELBOURNE', '45555454', '3000', 'VIC', '2021-05-11', '10:00:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"fO0K0EqXVKYAAAF5ig0dllkY\",\"shipment_reference\":\"545454\",\"shipment_creation_date\":\"2021-05-11T11:43:39+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":66.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"ZOMK0EqXbT0AAAF5iw0dllkY\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001378FPP00001\",\"consignment_id\":\"111Z50001378\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":599.78,\"total_cost_ex_gst\":545.25,\"shipping_cost\":545.25,\"total_gst\":54.53,\"freight_charge\":545.25,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T11:43:39+10:00\"}]}')
ERROR - 2021-05-11 03:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:43:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 03:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 03:43:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:26:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:26:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:26:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:26:37 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 04:27:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:27:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:27:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:27:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:27:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:27:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:27:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 04:27:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 04:27:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 04:27:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 04:28:09 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-11 04:28:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-11 04:28:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:28:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:28:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 04:28:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 04:28:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-11 04:28:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-11 04:28:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:28:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:28:50 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 04:28:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:28:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:32:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:33:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:33:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:36:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:36:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:39:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:40:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:40:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:44:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 04:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:48:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 04:48:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:12:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:12:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:13:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:14:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:14:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:16:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:16:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:18:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:18:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:20:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:20:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:20:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:32:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:32:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:33:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:33:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:34:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:34:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:35:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:42:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:42:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:44:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:44:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:47:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:47:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:51:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:51:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:51:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:51:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:52:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:52:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:53:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:53:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 237
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 378
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 380
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 381
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 382
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 383
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 384
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 385
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 386
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 387
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 296
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 33
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 37
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 49
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 49
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 145
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 146
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 147
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 150
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 151
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 159
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 160
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 162
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 163
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 164
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 474
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 475
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 476
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 478
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 479
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 480
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 480
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 480
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 484
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 485
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 486
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 487
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 489
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 490
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 491
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 491
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 491
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 495
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 496
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 497
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 498
ERROR - 2021-05-11 05:57:41 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 499
ERROR - 2021-05-11 05:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:57:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 237
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 378
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 380
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 381
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 382
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 383
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 384
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 385
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 386
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 387
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 296
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 33
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 37
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 49
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 49
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 145
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 146
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 147
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 150
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 151
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 159
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 160
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 162
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 163
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 164
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 474
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 475
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 476
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 477
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 478
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 479
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 480
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 480
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 480
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 484
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 485
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 486
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 487
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 488
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 489
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 490
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 491
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 491
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 491
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 495
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 496
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 497
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 498
ERROR - 2021-05-11 05:57:42 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 499
ERROR - 2021-05-11 05:57:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 05:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 27
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 27
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 05:59:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 05:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 05:59:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:01:14 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 06:01:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 06:01:14 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 06:01:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:01:30 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 06:01:30 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 06:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:01:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:03:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:06:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:06:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:07:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:07:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:07:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:07:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:07:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:10:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:10:34 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 06:10:34 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 06:10:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:10:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:21:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:21:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:21:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:21:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:22:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:22:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:22:30 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-11 06:22:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:22:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:22:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:23:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:23:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:23:34 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-11 06:25:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:25:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:25:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:25:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 06:25:56 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', '11', '4544545', '565656', 'rryryr', '5665656565', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '08 9302 1855', '6065', 'WA', '2021-05-11', '12:30:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"CyQK0EapwNkAAAF57KEdiVms\",\"shipment_reference\":\"565656\",\"shipment_creation_date\":\"2021-05-11T14:25:56+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":55.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"5z4K0EapOpMAAAF57qEdiVms\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001409FPP00001\",\"consignment_id\":\"111Z50001409\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":479.38,\"total_cost_ex_gst\":435.80,\"shipping_cost\":435.80,\"total_gst\":43.58,\"freight_charge\":435.80,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T14:25:56+10:00\"}]}')
ERROR - 2021-05-11 06:26:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 06:26:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:04:29 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:04:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:04:29 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 07:04:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 33
ERROR - 2021-05-11 07:04:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:04:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:05:10 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:05:10 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:05:10 --> Severity: Warning --> Attempt to read property "" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:05:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:06:10 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:06:10 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:06:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:06:28 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:06:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:06:28 --> Severity: Warning --> Attempt to read property "" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:06:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:06:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:06:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:06:40 --> Severity: error --> Exception: Call to undefined method User_model::get_histroy_by_id() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-11 07:08:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:08:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:08:58 --> Severity: error --> Exception: Call to undefined method User_model::get_histroy_by_id() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-11 07:13:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:13:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:13:53 --> Severity: error --> Exception: Call to undefined method User_model::get_histroy_by_id() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-11 07:14:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:14:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:21:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:21:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:21:09 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:21:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:21:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:22:26 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 29
ERROR - 2021-05-11 07:22:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:22:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:24:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:24:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:24:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:24:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:24:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:24:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:24:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:24:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:24:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:25:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:25:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:27:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:27:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:36:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:36:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:36:32 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 427
ERROR - 2021-05-11 07:36:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 427
ERROR - 2021-05-11 07:36:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 427
ERROR - 2021-05-11 07:36:32 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 430
ERROR - 2021-05-11 07:36:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:36:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:36:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:36:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:38:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:38:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:39:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:39:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 30
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 30
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:39:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:39:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:39:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 30
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 30
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:40:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:40:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:40:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:42:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:42:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:43:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 27
ERROR - 2021-05-11 07:43:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:44:22 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:44:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:45:04 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:45:04 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:45:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:45:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:45:04 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:45:04 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:45:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:45:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:46:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:46:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:46:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:46:47 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:46:47 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:46:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:46:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:46:47 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:46:47 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:46:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:46:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:47:39 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:47:39 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:47:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:47:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:47:39 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:47:39 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:47:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:47:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:51:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:51:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:51:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:55:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:55:06 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 31
ERROR - 2021-05-11 07:55:06 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:55:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:55:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 394
ERROR - 2021-05-11 07:55:06 --> Severity: Warning --> Undefined variable $b C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 397
ERROR - 2021-05-11 07:55:06 --> Severity: Warning --> Attempt to read property "shipment_creation_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:55:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:55:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:55:33 --> Severity: Warning --> Attempt to read property "shipment_creation_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:55:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:56:44 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:56:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:56:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:56:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:57:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:57:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:57:15 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 07:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:57:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:59:08 --> Severity: error --> Exception: Call to undefined method User_model::get_history_by_id() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-11 07:59:18 --> Severity: error --> Exception: Call to undefined method User_model::get_history_by_id() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-11 07:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 07:59:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 07:59:49 --> Severity: error --> Exception: Call to undefined method User_model::get_history_by_id() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-11 08:00:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:00:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:01:01 --> Severity: Warning --> Attempt to read property "ready_date" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:01:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:01:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:01:35 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:01:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:02:32 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:02:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:02:34 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:02:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:02:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:02:41 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:02:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:03:18 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:03:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:03:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:04:22 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-11 08:04:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:04:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:04:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:04:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:10:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:10:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:16:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:16:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:35:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:35:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:35:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-11 08:35:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-11 08:36:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:36:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:36:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:36:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:36:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:36:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:36:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:36:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:36:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:36:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:36:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:36:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:38:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:38:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:38:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:38:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:41:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:41:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 08:41:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:41:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 08:43:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:43:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:43:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:43:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:54:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:54:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:54:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:54:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:55:04 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', 'ere434343', '343434343', 'erererere', '4343434343', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '08 9302 1855', '6065', 'WA', '2021-05-11', '15:00:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"68MK0EapjZoAAAF5mCkdiVo1\",\"shipment_reference\":\"343434343\",\"shipment_creation_date\":\"2021-05-11T16:55:04+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":40.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"p4QK0EapQDsAAAF5mSkdiVo1\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001453FPP00001\",\"consignment_id\":\"111Z50001453\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":884.35,\"total_cost_ex_gst\":803.95,\"shipping_cost\":803.95,\"total_gst\":80.40,\"freight_charge\":803.95,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T16:55:04+10:00\"}]}')
ERROR - 2021-05-11 08:55:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:55:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:55:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:56:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:57:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 08:57:20 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', '4454545', '545454545', 'erererere', '5454545', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '08 9302 1855', '6065', 'WA', '2021-05-11', '15:00:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"U_wK0Eap.bwAAAF5mT0diVo3\",\"shipment_reference\":\"545454545\",\"shipment_creation_date\":\"2021-05-11T16:57:20+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":55.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"eLsK0EapqlgAAAF5mj0diVo3\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001454FPP00001\",\"consignment_id\":\"111Z50001454\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":479.38,\"total_cost_ex_gst\":435.80,\"shipping_cost\":435.80,\"total_gst\":43.58,\"freight_charge\":435.80,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T16:57:20+10:00\"}]}')
ERROR - 2021-05-11 08:59:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 08:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:00:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:00:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:01:14 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-11 09:02:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:02:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:03:00 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-11 09:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:03:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:03:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:04:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:04:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:04:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:05:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:05:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:05:38 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', '454545', '54545', '45454545', '44545454', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '08 9302 1855', '6065', 'WA', '2021-05-11', '15:30:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"OgsK0EqXYgMAAAF5bdYdllo.\",\"shipment_reference\":\"54545\",\"shipment_creation_date\":\"2021-05-11T17:05:38+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":55.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"WiEK0EqX4lQAAAF5btYdllo.\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001456FPP00001\",\"consignment_id\":\"111Z50001456\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":479.38,\"total_cost_ex_gst\":435.80,\"shipping_cost\":435.80,\"total_gst\":43.58,\"freight_charge\":435.80,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T17:05:38+10:00\"}]}')
ERROR - 2021-05-11 09:06:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:06:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:10:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:11:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:11:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:11:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:11:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:11:43 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', '66565', '6767676', 'fgfgfgfg', '545454545', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '08 9302 1855', '6065', 'WA', '2021-05-11', '15:30:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"tT0K0EqXVM8AAAF5xGkdllpE\",\"shipment_reference\":\"6767676\",\"shipment_creation_date\":\"2021-05-11T17:11:43+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":66.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"Q7oK0EqXheoAAAF5xWkdllpE\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001457FPP00001\",\"consignment_id\":\"111Z50001457\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":599.78,\"total_cost_ex_gst\":545.25,\"shipping_cost\":545.25,\"total_gst\":54.53,\"freight_charge\":545.25,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T17:11:43+10:00\"}]}')
ERROR - 2021-05-11 09:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:13:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:14:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:14:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:14:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:14:55 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-11 09:16:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:16:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:17:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:17:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:17:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:17:58 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', 'ghghgh', '54545454', 'dfdfd', '56565656', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '065565656', '6065', 'WA', '2021-05-11', '15:30:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"mKIK0EapAv4AAAF5BiEdiVpK\",\"shipment_reference\":\"54545454\",\"shipment_creation_date\":\"2021-05-11T17:17:58+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":55.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"9vMK0EapYRwAAAF5ByEdiVpK\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001459FPP00001\",\"consignment_id\":\"111Z50001459\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":479.38,\"total_cost_ex_gst\":435.80,\"shipping_cost\":435.80,\"total_gst\":43.58,\"freight_charge\":435.80,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T17:17:58+10:00\"}]}')
ERROR - 2021-05-11 09:18:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:20:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:20:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:20:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-11 09:21:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:21:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:21:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 09:21:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:21:31 --> Query error: Unknown column 'special_delivery' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `shipapi_res`) VALUES ('10000015', '545454', '45454', 'fddre', '6566565656', '1', 'ITT BLAKERS PTY LTD', 'SAGAR KADAM', '29 PARAMOUNT DRIVE ', 'T', 'WANGARA', '065656565', '6065', 'WA', '2021-05-11', '15:30:00', '17:30:00', '1', '1', 'Front Desk', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"udIK0EqXvm4AAAF5TGEdllpN\",\"shipment_reference\":\"45454\",\"shipment_creation_date\":\"2021-05-11T17:21:31+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":55.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"oOMK0EqXr98AAAF5TmEdllpN\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001461FPP00001\",\"consignment_id\":\"111Z50001461\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":479.38,\"total_cost_ex_gst\":435.80,\"shipping_cost\":435.80,\"total_gst\":43.58,\"freight_charge\":435.80,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-11T17:21:31+10:00\"}]}')
ERROR - 2021-05-11 09:23:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 09:23:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:01:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:01:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:01:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 79
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 79
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-11 10:02:40 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-11 10:02:40 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-11 10:02:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:02:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:03:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:04:06 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:04:06 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:04:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:04:09 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:04:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:04:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:04:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:04:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:04:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:05:09 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:05:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:05:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:05:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:06:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 10:06:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 10:06:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 10:06:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 10:06:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 10:06:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-11 10:06:51 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 10:06:51 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-11 10:07:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:07:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:07:23 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:07:23 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:07:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:07:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:12:36 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:12:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:12:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:12:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:12:41 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:12:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:12:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:12:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:12:44 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:12:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:12:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:17:44 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:17:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:17:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:17:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:17:47 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:17:47 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 89
ERROR - 2021-05-11 10:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:17:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:26:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:26:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:27:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:27:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:27:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:27:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:27:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:27:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:30:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:31:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:31:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:32:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:32:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:32:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:34:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:34:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:34:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:38:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:38:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:39:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:39:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:39:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:45:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:45:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:46:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:46:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:46:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:46:53 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:46:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:46:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:46:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:48:44 --> Severity: Warning --> Undefined variable $historys C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:48:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history.php 333
ERROR - 2021-05-11 10:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:48:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:50:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:51:01 --> 404 Page Not Found: customer/View_thermal_labelix/index
ERROR - 2021-05-11 10:52:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:52:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:52:08 --> 404 Page Not Found: customer/View_thermal_labelix/index
ERROR - 2021-05-11 10:52:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:52:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:52:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:52:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:52:53 --> 404 Page Not Found: customer/View_thermal_labelix/index
ERROR - 2021-05-11 10:53:01 --> 404 Page Not Found: customer/View_manifestix/index
ERROR - 2021-05-11 10:53:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:53:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:53:51 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:53:53 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:53:55 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:53:58 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:54:01 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:54:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:54:11 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:55:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:55:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:58:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:58:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:59:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:59:04 --> 404 Page Not Found: Track/index
ERROR - 2021-05-11 10:59:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 10:59:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 10:59:42 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 841
ERROR - 2021-05-11 11:00:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-11 11:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-11 11:00:27 --> 404 Page Not Found: Track/index
