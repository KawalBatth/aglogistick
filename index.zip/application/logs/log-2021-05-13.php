<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-13 02:34:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:34:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:34:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-13 02:34:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-13 02:34:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:34:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:34:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-13 02:34:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-13 02:34:31 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-13 02:34:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-13 02:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:34:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:34:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:34:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:34:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:34:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:34:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:34:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:35:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-13 02:36:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:36:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:36:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:36:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:36:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:37:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:37:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:37:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:37:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:37:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:37:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:37:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:38:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:38:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:38:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:38:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:41:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:41:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-13 02:41:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:41:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-13 02:42:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:42:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:42:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:42:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:43:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:46:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:50:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:50:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:50:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:50:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 02:51:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 02:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:01:11 --> Severity: Warning --> Undefined array key "shipment_creation_date" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 92
ERROR - 2021-05-13 03:01:11 --> Severity: Warning --> Undefined array key "shipment_creation_date" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 92
ERROR - 2021-05-13 03:01:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:01:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:03:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:03:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:08:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:13:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:13:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:13:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:13:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:13:49 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 870
ERROR - 2021-05-13 03:13:49 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 870
ERROR - 2021-05-13 03:13:49 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 871
ERROR - 2021-05-13 03:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:14:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:16:56 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 92
ERROR - 2021-05-13 03:16:56 --> Severity: Warning --> Undefined array key "ready_date" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 92
ERROR - 2021-05-13 03:16:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:17:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:20:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:22:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:23:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:23:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:23:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:26:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:26:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:29:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:29:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:29:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:29:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:31:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:31:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:35:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:35:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:36:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:36:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:39:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:39:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:40:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:40:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:40:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:40:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:42:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:42:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:42:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:42:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:44:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:44:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:44:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:44:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:44:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:49:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:49:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:50:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:50:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:51:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:51:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:54:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:54:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:55:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:55:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 03:57:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 03:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:16:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:16:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:19:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:20:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:20:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:25:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:25:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:28:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:28:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:30:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:30:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:34:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:39:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:39:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:39:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:39:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:40:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:41:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:41:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:42:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:42:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:43:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:43:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:45:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:45:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:47:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:47:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:47:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:47:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:48:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:49:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:49:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:49:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:49:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:50:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:50:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:53:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:53:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:56:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:57:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 04:59:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:59:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 04:59:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:01:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:03:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:03:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:03:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:03:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:03:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:03:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:05:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:06:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:06:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:06:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:07:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:07:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:07:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:07:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:07:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:08:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:08:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:11:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:11:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:11:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:11:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:11:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:11:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:15:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:16:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:16:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:16:52 --> 404 Page Not Found: customer/Customers/history_void
ERROR - 2021-05-13 05:17:13 --> 404 Page Not Found: customer/Customers/history_void
ERROR - 2021-05-13 05:17:42 --> 404 Page Not Found: Customers/history_void
ERROR - 2021-05-13 05:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:18:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:18:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:18:25 --> 404 Page Not Found: Customers/history_void
ERROR - 2021-05-13 05:20:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:20:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:20:28 --> 404 Page Not Found: Customers/history_void
ERROR - 2021-05-13 05:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:20:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:21:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:21:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:21:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:21:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:24:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:24:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:28:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:29:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:29:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:29:09 --> Severity: Warning --> Undefined variable $tableId C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 169
ERROR - 2021-05-13 05:29:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 2
ERROR - 2021-05-13 05:29:09 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 2
ERROR - 2021-05-13 05:29:09 --> Severity: Warning --> Undefined variable $tarcking C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 32
ERROR - 2021-05-13 05:29:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:29:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:31:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:34:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:34:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:35:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:35:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 26
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 26
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> Undefined variable $tracking C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 455
ERROR - 2021-05-13 05:36:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 455
ERROR - 2021-05-13 05:36:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:36:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:41:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:41:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> Undefined variable $history C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 26
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 26
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> Undefined variable $tracking C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 455
ERROR - 2021-05-13 05:41:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 455
ERROR - 2021-05-13 05:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:41:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:42:08 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\history_void.php 26
ERROR - 2021-05-13 05:42:08 --> Severity: Warning --> Undefined variable $datas C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:42:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:42:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 450
ERROR - 2021-05-13 05:42:08 --> Severity: Warning --> Undefined variable $tracking C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 455
ERROR - 2021-05-13 05:42:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 455
ERROR - 2021-05-13 05:42:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:42:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:42:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 05:42:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:53:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 05:53:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 06:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-13 06:10:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 06:11:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-13 06:11:10 --> 404 Page Not Found: Assets/css
