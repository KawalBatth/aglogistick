<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-21 03:25:32 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:32 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:38 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:43 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:43 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:46 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:25:46 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:30:13 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:30:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:34 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:41 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:43 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:45 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:31:47 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:47 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:50 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:50 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:52 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:52 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:55 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:31:55 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:34:18 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:34:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:34:18 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:34:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:34:45 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:34:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:34:49 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:34:49 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:34:53 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:34:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:37:35 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:37:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:39:27 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:39:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:40:43 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:40:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:44:53 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:48:23 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:48:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:49:02 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:49:43 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:49:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:50:32 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:50:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:51:12 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:51:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:52:50 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:52:50 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_add.php 744
ERROR - 2021-04-21 03:57:10 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:57:10 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:57:15 --> Severity: Warning --> Undefined variable $user_note C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 03:57:15 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 8346
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:06:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:07:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:08:37 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 04:08:52 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 04:09:22 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:09:58 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 04:10:07 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:10:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:04 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:12 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:11:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5602
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:35:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:36:44 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5062
ERROR - 2021-04-21 04:37:54 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:44:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5043
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:46:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 5030
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:53:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:55:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:56:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:57:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:05 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-21 04:58:16 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:58:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 04:59:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:00:55 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:01:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:03:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:06:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:09:10 --> 404 Page Not Found: Customers/shipment
ERROR - 2021-04-21 05:09:26 --> 404 Page Not Found: Customers/help
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:10:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:11:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 05:26:27 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:26:27 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:31:33 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:31:33 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:31:48 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:31:48 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:37:59 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:37:59 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:39:34 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:39:34 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:48:18 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:48:18 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:48:21 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:48:21 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:48:50 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:48:50 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 348
ERROR - 2021-04-21 05:49:09 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 890
ERROR - 2021-04-21 05:49:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 890
ERROR - 2021-04-21 05:49:49 --> Severity: Warning --> Undefined variable $carriers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 890
ERROR - 2021-04-21 05:49:49 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 890
ERROR - 2021-04-21 05:53:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 05:53:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 05:53:19 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 05:57:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 05:57:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 05:57:34 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 05:57:46 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 05:58:04 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 151
ERROR - 2021-04-21 05:58:04 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` IS NULL
AND `receiver_postcode` IS NULL
ERROR - 2021-04-21 06:06:29 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = ''
AND `receiver_postcode` = ''
ERROR - 2021-04-21 06:09:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 06:09:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 06:09:16 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Sydney'
AND `receiver_postcode` = '1001'
ERROR - 2021-04-21 06:10:07 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 151
ERROR - 2021-04-21 06:10:07 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` IS NULL
AND `receiver_postcode` IS NULL
ERROR - 2021-04-21 06:10:24 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Sydney'
AND `receiver_postcode` = '1001'
ERROR - 2021-04-21 06:14:49 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 06:17:27 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = ''
AND `receiver_postcode` = ''
ERROR - 2021-04-21 06:17:51 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 06:18:02 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 151
ERROR - 2021-04-21 06:18:02 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` IS NULL
AND `receiver_postcode` IS NULL
ERROR - 2021-04-21 06:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 06:20:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 06:20:22 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 06:20:31 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Melbourne'
AND `receiver_postcode` = '3000'
ERROR - 2021-04-21 06:20:41 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 156
ERROR - 2021-04-21 06:20:41 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` IS NULL
AND `receiver_postcode` IS NULL
ERROR - 2021-04-21 06:21:28 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 151
ERROR - 2021-04-21 06:21:28 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` IS NULL
AND `receiver_postcode` IS NULL
ERROR - 2021-04-21 06:57:13 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 06:57:14 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-21 06:57:22 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Sydney'
AND `receiver_postcode` = '1001'
ERROR - 2021-04-21 06:57:35 --> Query error: Unknown column 'receiver_zone' in 'field list' - Invalid query: SELECT `receiver_zone`
FROM `receiver_zone`
WHERE `receiver_suburb` = 'Sydney'
AND `receiver_postcode` = '1001'
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:03:45 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 07:05:18 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 07:05:30 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:06:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:24 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-21 07:09:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
