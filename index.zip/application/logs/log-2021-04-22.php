<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-22 03:15:06 --> 404 Page Not Found: admin/Add_weight_breakix/index
ERROR - 2021-04-22 03:15:12 --> 404 Page Not Found: admin/Add_weight_breakix/index
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:16:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:10 --> 404 Page Not Found: admin/Get_fix_rates/index
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:41 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:17:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:08 --> 404 Page Not Found: admin/Get_fix_rates/index
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:18:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> Undefined variable $zones C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:19:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4180
ERROR - 2021-04-22 03:21:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:21:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:22:17 --> Query error: Table 'webfreight.temp_data' doesn't exist - Invalid query: INSERT INTO `temp_data` (`user_id`, `formdata`) VALUES ('7', 'shipmentPage.senderAddress.companyName=pankaj&shipmentPage.senderAddress.phone=08 94793399&shipmentPage.senderAddress.contactName=DESPATCH&shipmentPage.senderAddress.email=logistics@agllogistics.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=U1 / 11 FRICKER ROAD&shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=PERTH AIRPORT&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=toll&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=kawal&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=12&shipmentPage.receiverAddress.address=&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=Melbourne&shipmentPage.receiverAddress.postalCode=3000&shipmentPage.receiverAddress.state=VIC&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=2&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=40&total_weight=74.00&shipmentPage.pieces.dimensionL1=40&shipmentPage.pieces.dimensionW1=30&shipmentPage.pieces.dimensionH1=24&get_volume=113984.000&shipmentPage.pieces.quantity1=1&final_total=2&shipmentPage.pieces.weight1=34&shipmentPage.pieces.dimensionL1=44&shipmentPage.pieces.dimensionW1=44&shipmentPage.pieces.dimensionH1=44&shipmentPage.pieces.quantity1=1&shipmentPage.isAddPiece=true&shipmentPage.addCons[0].addConName=Dangerous Goods&shipmentPage.addCons[0].addConCode=dangerousgoods&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=&shipmentPage.addCons[2].value=0&shipmentPage.addCons[2].addConName=agl Warranty&shipmentPage.addCons[2].addConCode=aglWarranty')
ERROR - 2021-04-22 03:22:19 --> Query error: Table 'webfreight.temp_data' doesn't exist - Invalid query: INSERT INTO `temp_data` (`user_id`, `formdata`) VALUES ('7', 'shipmentPage.senderAddress.companyName=pankaj&shipmentPage.senderAddress.phone=08 94793399&shipmentPage.senderAddress.contactName=DESPATCH&shipmentPage.senderAddress.email=logistics@agllogistics.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=U1 / 11 FRICKER ROAD&shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=PERTH AIRPORT&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=toll&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=kawal&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=12&shipmentPage.receiverAddress.address=&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=Melbourne&shipmentPage.receiverAddress.postalCode=3000&shipmentPage.receiverAddress.state=VIC&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=2&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=40&total_weight=74.00&shipmentPage.pieces.dimensionL1=40&shipmentPage.pieces.dimensionW1=30&shipmentPage.pieces.dimensionH1=24&get_volume=113984.000&shipmentPage.pieces.quantity1=1&final_total=2&shipmentPage.pieces.weight1=34&shipmentPage.pieces.dimensionL1=44&shipmentPage.pieces.dimensionW1=44&shipmentPage.pieces.dimensionH1=44&shipmentPage.pieces.quantity1=1&shipmentPage.isAddPiece=true&shipmentPage.addCons[0].addConName=Dangerous Goods&shipmentPage.addCons[0].addConCode=dangerousgoods&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=&shipmentPage.addCons[2].value=0&shipmentPage.addCons[2].addConName=agl Warranty&shipmentPage.addCons[2].addConCode=aglWarranty')
ERROR - 2021-04-22 03:23:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:23:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:23:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:23:12 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:23:16 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:24:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 03:24:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 04:11:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 04:11:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 04:53:10 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 04:54:12 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 04:54:15 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 04:54:17 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:16:27 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:16:32 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:18:08 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:25:00 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:25:14 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:26:06 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:26:09 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 05:31:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:31:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:31:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:31:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:32:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 05:42:47 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 05:46:47 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 05:47:16 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 05:49:17 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 05:50:29 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 06:01:32 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 06:02:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:02:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:02:28 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 06:02:43 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 06:03:55 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:03:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:04:35 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:06:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:09:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:09:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:09:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:11:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:11:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:23:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:23:13 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:24:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:24:28 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:25:00 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:28:20 --> Severity: error --> Exception: array_sum(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 172
ERROR - 2021-04-22 06:29:15 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:29:25 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:30:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 163
ERROR - 2021-04-22 06:58:17 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:58:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:50 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:50 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 06:59:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-22 07:02:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 61
ERROR - 2021-04-22 07:02:06 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 61
ERROR - 2021-04-22 07:03:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 61
ERROR - 2021-04-22 07:03:01 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 61
ERROR - 2021-04-22 07:03:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1713
ERROR - 2021-04-22 07:03:01 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1713
ERROR - 2021-04-22 07:05:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 61
ERROR - 2021-04-22 07:05:17 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 61
ERROR - 2021-04-22 07:05:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1713
ERROR - 2021-04-22 07:05:17 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1713
ERROR - 2021-04-22 07:21:12 --> 404 Page Not Found: customer/Images/LOGOiN.png
ERROR - 2021-04-22 07:58:00 --> 404 Page Not Found: customer/Images/LOGOiN.png
ERROR - 2021-04-22 07:58:27 --> 404 Page Not Found: customer/Images/LOGOiN.png
ERROR - 2021-04-22 08:26:44 --> Severity: error --> Exception: syntax error, unexpected token "<", expecting end of file C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1754
ERROR - 2021-04-22 08:52:34 --> Severity: error --> Exception: Undefined constant "format" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1755
ERROR - 2021-04-22 10:35:02 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1770
ERROR - 2021-04-22 10:35:02 --> Severity: error --> Exception: Value of type null is not callable C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1770
ERROR - 2021-04-22 10:35:31 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1770
ERROR - 2021-04-22 10:35:31 --> Severity: error --> Exception: Value of type null is not callable C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1770
ERROR - 2021-04-22 10:44:12 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1770
ERROR - 2021-04-22 10:44:12 --> Severity: error --> Exception: Value of type null is not callable C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1770
