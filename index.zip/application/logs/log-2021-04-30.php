<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-30 02:28:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:28:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:28:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:28:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:28:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:28:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:28:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:28:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:34:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:34:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:35:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:35:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:35:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:35:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:35:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:35:47 --> Severity: error --> Exception: Call to undefined function pg_query() C:\xampp\htdocs\webfreight\application\controllers\admin\Rates.php 49
ERROR - 2021-04-30 02:35:48 --> Severity: error --> Exception: Call to undefined function pg_query() C:\xampp\htdocs\webfreight\application\controllers\admin\Rates.php 49
ERROR - 2021-04-30 02:35:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:35:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:36:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:36:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:36:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:36:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:36:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:36:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:36:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:36:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:44:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:44:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:44:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:44:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:47:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:47:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:47:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:47:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:55:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:55:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:55:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:55:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:57:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:57:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:57:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:57:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:58:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:58:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:58:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:58:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 02:58:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:58:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 02:58:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 02:58:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:01:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:01:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:01:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:01:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:02:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:02:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:02:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:02:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:03:56 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-30 03:04:11 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-30 03:04:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:04:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:04:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:04:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:05:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:05:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:05:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:05:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:05:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:05:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:05:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:05:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:07:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:07:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:07:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:07:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:08:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:08:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:08:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:08:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:09:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:09:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:09:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:09:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:10:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:10:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:10:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:10:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:10:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:10:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:10:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:10:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:11:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:11:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:11:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:11:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:12:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:12:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:12:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:12:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:13:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:13:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:13:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:13:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:15:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:15:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:15:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:15:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:16:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:16:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:16:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:16:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:16:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:16:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:16:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:16:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:17:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:17:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:17:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:17:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:18:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:18:41 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:18:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:18:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:18:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:18:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:18:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:18:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:19:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:19:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:19:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:19:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:20:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:20:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:20:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:20:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:22:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:22:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:22:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:22:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:24:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:24:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:24:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:24:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:24:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:24:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:24:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:24:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:24:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:28:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:28:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:28:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:28:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:29:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:29:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:29:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:29:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:30:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:30:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:30:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:30:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:33:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:33:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:33:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:33:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:33:50 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-30 03:34:07 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-30 03:34:32 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-30 03:34:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:34:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:34:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:34:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:34:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:34:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:34:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:34:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:35:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:35:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:35:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:35:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:36:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:36:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:36:51 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:36:51 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:37:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:37:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:37:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:37:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:38:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:38:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:39:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:39:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:39:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:39:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:39:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:39:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:39:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:39:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:39:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:39:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:39:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:39:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:40:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:40:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:40:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:40:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:40:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:40:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:40:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:40:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:40:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:40:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:40:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:40:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:41:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:41:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:41:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:41:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:41:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:41:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:41:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:41:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:42:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:42:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:42:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:42:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:42:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:42:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:42:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:42:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:44:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:44:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:44:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:44:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:45:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:45:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:45:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:45:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:45:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:45:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:45:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:45:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:48:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:48:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:48:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:48:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:48:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:48:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:48:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:48:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:49:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:49:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:49:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:49:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:50:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:50:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:50:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:50:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:52:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:52:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:52:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:52:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:53:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:53:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:53:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:53:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:53:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:53:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:53:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:53:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:54:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:54:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:54:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:54:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:55:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:55:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:55:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:55:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:57:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:57:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:57:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:57:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:57:38 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-30 03:58:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:58:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:58:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:58:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:58:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:58:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:58:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:58:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 03:58:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:58:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:58:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:58:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:59:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:59:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 03:59:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 03:59:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:00:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:00:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:00:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:00:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:00:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:00:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:00:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:00:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:01:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:01:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:01:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:01:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:01:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:01:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:01:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:01:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:01:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:01:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:01:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:01:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:14 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:04:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:04:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:05:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:05:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:05:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:05:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:07:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:07:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:07:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:07:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:07:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:07:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:07:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:07:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:08:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:08:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:08:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:08:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:09:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:09:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:09:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:09:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:09:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:09:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:09:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:09:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:10:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:10:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:10:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:10:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:11:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:11:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:11:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:11:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:11:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:11:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:11:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:11:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:11:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:11:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:11:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:11:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:12:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:12:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:12:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:12:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:13:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:13:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:13:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:13:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:13:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:13:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:13:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:13:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:14:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:14:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:15:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:15:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:15:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:15:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:15:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:15:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:15:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:15:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:15:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:15:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:15:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:15:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:16:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:16:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:16:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:16:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:16:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:16:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:16:38 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:16:38 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:16:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:16:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:16:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:16:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:10 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:17:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:17:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:17:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:18:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:18:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:18:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:18:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:19:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:19:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:19:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:19:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:19:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:19:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:19:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:19:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:20:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:20:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:20:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:20:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:20:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:20:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:20:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:20:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:22:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:22:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:22:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:22:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:23:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:23:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:23:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:23:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:23:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:23:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:23:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:23:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:24:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:24:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:24:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:24:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:26:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:26:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:26:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:26:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:26:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:26:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:26:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:26:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:26:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:26:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:27:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:27:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:27:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:27:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:27:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:27:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:27:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:27:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:28:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:28:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:28:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:28:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:29:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:29:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:29:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:29:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:30:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:30:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:30:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:30:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:30:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:30:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:30:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:30:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:30:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:30:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:30:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:30:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:31:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:31:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:31:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:31:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:31:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:31:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:31:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:31:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:31:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:31:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:31:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:31:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:32:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:32:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:32:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:32:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:33:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:33:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:33:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:33:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:33:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:33:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:33:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:33:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:34:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:34:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:34:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:34:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:34:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:34:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:34:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:34:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:35:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:35:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:35:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:35:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:36:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:36:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:36:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:36:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:36:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:36:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:36:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:36:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:37:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:37:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:37:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:37:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:40:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:40:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:40:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:40:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:40:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:40:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:40:33 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:40:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:47:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:47:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:47:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:47:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:48:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:48:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:48:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:48:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:48:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:48:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:48:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:48:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:49:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:49:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:49:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:49:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:50:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:50:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:50:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:50:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:50:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:50:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:50:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:50:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:51:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:51:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:51:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:51:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:52:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:52:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:52:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:52:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:52:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:52:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:52:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:52:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:53:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:53:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:53:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:53:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:55:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:55:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:55:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:55:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:55:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:55:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:55:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:55:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:56:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:56:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:56:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:56:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:57:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:57:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:57:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:57:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:57:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:57:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:57:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:57:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 04:58:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:58:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 04:58:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 04:58:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:00:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:00:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:00:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:00:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:00:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:00:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:00:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 05:00:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 05:03:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:03:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:03:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:03:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:04:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:04:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:04:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:04:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:05:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:05:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-30 05:05:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 05:05:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 05:07:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:07:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:07:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 05:07:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-30 05:08:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:08:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:08:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:08:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:10:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:10:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:10:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:10:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:10:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:10:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:10:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:10:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:12:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:12:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:12:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:12:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:14:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:14:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:14:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:14:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:14:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:14:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:16:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:16:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:16:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:16:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:16:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:16:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:16:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:16:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:17:04 --> 404 Page Not Found: Customers/shipment
ERROR - 2021-04-30 05:17:09 --> 404 Page Not Found: Customert/index
ERROR - 2021-04-30 05:17:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:17:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:17:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:17:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:22:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:22:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:22:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:22:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:22:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:22:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:22:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:22:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:22:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:22:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:22:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:22:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:24:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:24:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 05:24:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 05:24:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:03:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:03:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:03:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:03:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:03:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:03:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:03:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:03:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:05:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:05:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:05:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:05:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:06:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:06:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:06:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:06:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:07:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:07:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:07:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:07:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:07:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:07:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:07:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:08:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:20:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:20:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:20:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:20:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:20:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:20:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 709
ERROR - 2021-04-30 06:20:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:20:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:21:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:21:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:21:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:21:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:21:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:21:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:21:59 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:22:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:27:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:27:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:27:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:27:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:27:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:27:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:27:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:27:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:28:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:28:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:28:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:28:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:28:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:28:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:28:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:28:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:28:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:28:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:28:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:28:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:29:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:29:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:29:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:29:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:29:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:29:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 06:29:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 06:29:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:21:23 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 08:21:55 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> Severity: Warning --> Undefined array key "margin_rate" C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:26:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:26:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:27:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:27:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:27:01 --> Severity: error --> Exception: htmlspecialchars(): Argument #1 ($string) must be of type string, array given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 4153
ERROR - 2021-04-30 08:27:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:27:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:27:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:27:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:27:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:27:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:28:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:28:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:28:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:28:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:29:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:29:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:29:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:29:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:31:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:31:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:31:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:31:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:32:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:32:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:32:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:32:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:32:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:32:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:32:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:32:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:34:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:34:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:34:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:34:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:35:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:35:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:35:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:35:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:36:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:36:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:36:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:36:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:36:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:36:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:36:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:36:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:41:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:41:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:41:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:41:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:42:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:42:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:42:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:42:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:43:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:43:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:43:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:43:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:44:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:44:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:44:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:44:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:46:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:46:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:46:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:46:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:46:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:46:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-04-30 08:46:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:46:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-30 08:48:35 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-30 10:01:06 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-30 10:01:06 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-30 10:02:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:02:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:36 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:24:36 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:24:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:24:37 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:46:17 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:46:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:46:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:46:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:46:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:46:21 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:46:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:46:21 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:48:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:48:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:48:50 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:48:50 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:48:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:48:51 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:48:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:48:52 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:49:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:01 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:49:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:01 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:49:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:03 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:05 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:49:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:06 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:49:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:49:07 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:53:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:53:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:53:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:53:29 --> 404 Page Not Found: Customers/get_receiver
ERROR - 2021-04-30 10:53:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:53:30 --> 404 Page Not Found: Customers/get_receiver
ERROR - 2021-04-30 10:53:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:53:31 --> 404 Page Not Found: Customers/get_receiver
ERROR - 2021-04-30 10:54:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:54:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:54:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:54:20 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:56:23 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:56:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:56:26 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:56:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:56:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:56:26 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:57:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:32 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:57:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:33 --> 404 Page Not Found: customer/Get_receiver/index
ERROR - 2021-04-30 10:57:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:53 --> Query error: Unknown column 'suburb' in 'where clause' - Invalid query: SELECT *
FROM `address_book`
WHERE `suburb` LIKE '%kaw%'
 LIMIT 5
ERROR - 2021-04-30 10:57:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:57:53 --> Query error: Unknown column 'suburb' in 'where clause' - Invalid query: SELECT *
FROM `address_book`
WHERE `suburb` LIKE '%kawa%'
 LIMIT 5
ERROR - 2021-04-30 10:58:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:12 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:12 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:13 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:33 --> 404 Page Not Found: customer/Customer/get_receiver
ERROR - 2021-04-30 10:58:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:34 --> 404 Page Not Found: customer/Customer/get_receiver
ERROR - 2021-04-30 10:58:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:52 --> Query error: Unknown column 'suburb' in 'where clause' - Invalid query: SELECT *
FROM `address_book`
WHERE `suburb` LIKE '%kaw%'
 LIMIT 5
ERROR - 2021-04-30 10:58:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-30 10:58:53 --> Query error: Unknown column 'suburb' in 'where clause' - Invalid query: SELECT *
FROM `address_book`
WHERE `suburb` LIKE '%kawa%'
 LIMIT 5
