<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-28 03:03:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:03:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:03:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:03:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:03:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:03:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:03:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:03:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:03:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:03:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:03:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:05:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:05:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:05:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:05:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:08:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:08:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:09:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:09:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:09:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:09:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:09:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:09:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:09:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:09:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:10:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:10:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:10:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:10:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:11:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:11:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:11:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:11:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:12:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:12:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:12:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:12:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:13:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:13:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:13:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:13:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:13:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:13:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:13:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:13:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:13:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:13:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:13:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:13:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 03:21:44 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 03:21:44 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 03:26:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:26:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:26:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:26:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:26:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:26:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:26:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:26:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:26:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:26:41 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:26:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:26:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:27:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:27:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:27:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:27:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:27:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:27:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:27:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:27:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:27:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:27:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:27:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:27:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:36:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:36:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:36:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:36:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:40:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:40:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:40:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:40:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:46:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:46:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:46:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:46:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:46:36 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:47:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:47:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:47:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:47:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:47:39 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:47:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:47:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:47:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:47:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:48:02 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:48:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:48:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:48:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:48:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:48:43 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:48:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:48:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:48:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:48:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:49:02 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:49:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:49:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:49:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:49:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:49:46 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:50:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:50:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:50:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:50:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 03:51:02 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-04-28 03:51:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:51:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:51:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:51:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:51:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:51:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:51:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:51:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:52:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:52:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:53:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:53:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:53:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:53:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:53:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:53:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:53:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:53:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:54:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:54:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:54:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:54:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:55:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:55:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:55:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:55:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:55:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:55:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:55:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:55:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:56:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:56:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:56:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:56:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:56:22 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-28 03:56:35 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-28 03:57:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:57:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:57:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:57:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:58:09 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-28 03:58:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:58:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:58:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:58:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:59:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:59:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 03:59:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 03:59:22 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:09:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:09:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:09:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:09:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:24:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:24:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:24:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:24:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:25:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:25:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:25:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:25:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:28:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:28:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:28:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:28:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:29:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:29:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:29:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:29:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:29:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:29:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:29:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:29:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:29:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:29:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:29:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:29:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:30:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:30:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:30:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:30:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:30:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:30:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:30:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:30:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:31:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:31:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:31:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:31:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:31:24 --> Query error: Column 'customer_id' cannot be null - Invalid query: INSERT INTO `margin` (`customer_id`, `service_name`, `margin`) VALUES (NULL, 'Fixed Price Premium 20kg', '00.00')
ERROR - 2021-04-28 04:33:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:33:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:33:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:33:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:33:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:33:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:34:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:34:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:34:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 6
ERROR - 2021-04-28 04:34:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 04:34:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 04:34:58 --> Severity: error --> Exception: syntax error, unexpected string content "admin/add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:35:04 --> Severity: error --> Exception: syntax error, unexpected string content "admin/add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:35:07 --> Severity: error --> Exception: syntax error, unexpected string content "admin/add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:35:16 --> 404 Page Not Found: admin/Add_customer/index
ERROR - 2021-04-28 04:35:19 --> Severity: error --> Exception: syntax error, unexpected string content "admin/add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:35:22 --> Severity: error --> Exception: syntax error, unexpected string content "admin/add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:35:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:35:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:35:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:35:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:39:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:39:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:39:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:39:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:39:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:39:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:39:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 6
ERROR - 2021-04-28 04:39:14 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 04:39:14 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-28 04:40:19 --> Severity: error --> Exception: syntax error, unexpected string content "admin/customers/customer_add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:40:21 --> Severity: error --> Exception: syntax error, unexpected string content "admin/customers/customer_add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:40:22 --> Severity: error --> Exception: syntax error, unexpected string content "admin/customers/customer_add);" C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 406
ERROR - 2021-04-28 04:40:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:40:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:40:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:40:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:40:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:40:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:40:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:40:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:41:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:41:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:41:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:41:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:42:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:42:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-28 04:42:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:42:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-28 04:47:09 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 18
ERROR - 2021-04-28 04:47:09 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 18
ERROR - 2021-04-28 04:47:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 18
ERROR - 2021-04-28 04:47:34 --> Severity: Warning --> Undefined array key "shipment_type" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 18
ERROR - 2021-04-28 04:52:54 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 12
ERROR - 2021-04-28 04:53:24 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\webfreight\application\views\customers\quote.php 12
ERROR - 2021-04-28 04:53:42 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\webfreight\application\views\customers\quote.php 12
ERROR - 2021-04-28 04:53:42 --> Severity: Warning --> Attempt to read property "" on array C:\xampp\htdocs\webfreight\application\views\customers\quote.php 12
ERROR - 2021-04-28 04:53:59 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 12
ERROR - 2021-04-28 04:54:15 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\webfreight\application\views\customers\quote.php 12
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:10:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:10:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:10:57 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:10:57 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:13:08 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:13:08 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:15:32 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:15:32 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:15:50 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:15:50 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:17:29 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:17:29 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:17:41 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:17:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:18:07 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:18:07 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:18:09 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:18:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:19:01 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:19:01 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:19:13 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:19:13 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:20:07 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:20:07 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:21:56 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:21:56 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:09 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:09 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:39 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:39 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:54 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:54 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:22:58 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:22:58 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:24:02 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:24:02 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:24:58 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:24:58 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:25:10 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:25:10 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:26:27 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:26:27 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:27:57 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:27:57 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:28:08 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:28:08 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:31:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:31:41 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:31:41 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:31:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:31:51 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:31:51 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:32:41 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:32:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:32:48 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:32:48 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:33:03 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:33:03 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:33:58 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:33:58 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:34:08 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:34:08 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:39:55 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:39:55 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:40:20 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:40:20 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:40:29 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:40:29 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:41:34 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:41:34 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-28 05:41:41 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:41:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-28 05:53:54 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:53:54 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:53:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:56:30 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:56:30 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:56:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:57:04 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:57:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 05:57:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:06:36 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:06:36 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:06:36 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:06:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:07:28 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:07:28 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:07:28 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:07:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:07:49 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:07:49 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:07:49 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:07:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:09:20 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:09:20 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:09:20 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:09:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:10:09 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:10:09 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:10:09 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:10:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:12:04 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:12:04 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:12:04 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:12:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 234
ERROR - 2021-04-28 06:13:03 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:13:08 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:13:14 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:14:24 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:14:28 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:14:43 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 06:15:18 --> Severity: Warning --> Undefined variable $quote_Id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 129
ERROR - 2021-04-28 07:05:59 --> 404 Page Not Found: customer/Customers/get_quote
ERROR - 2021-04-28 07:06:42 --> 404 Page Not Found: customer/Customers/get_quote
ERROR - 2021-04-28 07:07:37 --> 404 Page Not Found: customer/Get_quote/index
ERROR - 2021-04-28 07:15:22 --> Severity: error --> Exception: Call to undefined method Auth_model::get_quote() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 128
ERROR - 2021-04-28 07:17:21 --> 404 Page Not Found: customer/Customers/get_quote
ERROR - 2021-04-28 07:17:40 --> 404 Page Not Found: customer/Get_quote/index
ERROR - 2021-04-28 07:18:54 --> 404 Page Not Found: customer/Customers/gets_quote
ERROR - 2021-04-28 07:22:11 --> Severity: error --> Exception: Call to undefined method User_model::gets_quote() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 130
ERROR - 2021-04-28 07:22:33 --> Severity: error --> Exception: Call to undefined method User_model::gets_quote() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 130
ERROR - 2021-04-28 07:22:36 --> Severity: error --> Exception: Call to undefined method User_model::gets_quote() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 130
ERROR - 2021-04-28 07:22:48 --> Severity: error --> Exception: Call to undefined method Auth_model::gets_quote() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 130
ERROR - 2021-04-28 07:23:49 --> 404 Page Not Found: customer/Gets_quote/index
ERROR - 2021-04-28 07:25:33 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 130
ERROR - 2021-04-28 07:25:33 --> Severity: Warning --> Undefined variable $quote C:\xampp\htdocs\webfreight\application\views\customers\quote.php 310
ERROR - 2021-04-28 07:25:33 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\quote.php 310
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 312
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 312
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 314
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 314
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 315
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 315
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 316
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 316
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 317
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 317
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 318
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 318
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 319
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 319
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 320
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 320
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 321
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 321
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 322
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 322
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\views\customers\quote.php 323
ERROR - 2021-04-28 07:30:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 323
ERROR - 2021-04-28 07:31:57 --> Severity: Warning --> Undefined variable $quote C:\xampp\htdocs\webfreight\application\views\customers\quote.php 310
ERROR - 2021-04-28 07:31:57 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\quote.php 310
ERROR - 2021-04-28 07:32:34 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\webfreight\application\views\customers\quote.php 310
ERROR - 2021-04-28 07:32:34 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\quote.php 310
