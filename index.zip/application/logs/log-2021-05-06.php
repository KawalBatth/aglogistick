<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-06 02:27:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'webnew' C:\xampp\htdocs\webfreight\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-06 02:27:13 --> Unable to connect to the database
ERROR - 2021-05-06 02:28:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:28:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:28:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:28:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:28:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:28:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:28:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:28:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:29:05 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-05-06 02:30:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:30:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:30:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:30:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:30:20 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-05-06 02:31:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:31:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:31:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:31:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:14 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 02:31:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:31:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:31:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:31:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:31:45 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-06 02:31:56 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-06 02:32:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:32:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:32:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:32:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:33:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:33:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:33:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:33:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:33:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:33:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:33:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:33:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:35:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:35:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:35:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:35:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:35:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:35:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:35:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:35:33 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:35:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:35:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:35:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:35:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:36:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:36:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 02:36:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:36:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 02:36:35 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 02:36:35 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 02:36:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:37:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:37:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:38:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:38:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:39:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:39:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:44:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:44:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:44:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:45:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:45:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:45:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:45:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:46:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:46:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:46:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:46:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:46:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:46:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:46:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:46:34 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 02:46:34 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 02:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:46:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:47:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:47:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 02:49:31 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 02:49:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:49:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:49:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:50:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:50:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:50:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:50:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:50:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 02:54:17 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 02:54:17 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 02:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:54:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:54:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:56 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:54:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 02:55:30 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 02:55:30 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 02:55:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:55:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:55:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:56:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:56:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:56:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:56:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:57:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:57:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:57:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 02:59:34 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-06 02:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 02:59:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:03:41 --> Severity: Warning --> Undefined variable $c C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-06 03:03:41 --> Severity: Warning --> Undefined array key "" C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-06 03:03:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-06 03:03:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:03:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:03:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:12:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:12:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:12:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:12:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:14:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:14:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:14:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:14:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:14:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:14:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:14:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:14:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:16:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:16:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:20:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:20:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:20:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:20:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:20:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:21:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:21:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:23:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:23:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:24:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:24:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:24:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:24:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:24:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:24:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:25:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:25:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 03:26:20 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 03:26:20 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 03:26:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:26:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:26:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:26:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:27:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:27:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:27:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:27:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:27:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:30:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:30:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:30:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:30:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:39 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:42 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-06 03:30:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:30:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:30:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:30:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:36:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:36:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:36:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:36:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:36:11 --> Severity: Warning --> Undefined variable $c_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 200
ERROR - 2021-05-06 03:41:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:41:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:41:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:41:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:41:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:41:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:41:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:41:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:42:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:42:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:42:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:42:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:43:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:43:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:43:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:43:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:44:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:44:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:44:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:44:20 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:45:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:45:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:45:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:45:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:46:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:46:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:46:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:46:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:48:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:48:41 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:48:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:48:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:48:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:48:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:48:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:48:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:49:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:49:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:49:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:49:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:50:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:50:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:50:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:50:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:51:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:51:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:51:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:51:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:52:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:52:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:52:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:52:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:54:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:54:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:54:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:54:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:54:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:54:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:54:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:54:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:55:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:55:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:55:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:55:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:56:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:56:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 03:56:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:56:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 03:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:56:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:57:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:57:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:57:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:45 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 03:58:45 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 03:58:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:58:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:59:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:59:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:59:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:59:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:59:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:59:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:59:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:59:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 03:59:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 03:59:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:00:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:00:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:00:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:00:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:00:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:00:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:00:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:01:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:02:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:02:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:03:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:04:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:04:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:04:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:05:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:05:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:06:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:06:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:06:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:06:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:06:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:07:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:08:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:08:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:09:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:09:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:09:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:09:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:09:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:09:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:09:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 04:11:00 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 04:11:00 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 912
ERROR - 2021-05-06 04:11:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:11:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:12:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:12:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:12:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:12:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:13:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:13:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:13:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:13:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:14:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:14:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:16:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:16:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:19:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:20:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:20:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:20:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:20:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:20:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:20:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:20:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:22:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:22:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:24:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:24:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:25:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:25:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:27:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:27:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:27:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:27:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:28:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:34:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:34:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:34:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:34:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:35:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:35:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:36:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:36:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:36:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:36:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:36:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:36:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:37:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:37:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:37:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:37:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:37:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:37:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:38:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 04:38:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 04:38:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 04:38:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 04:38:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 04:38:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 04:38:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 04:38:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 04:40:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:41:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:44:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:44:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:44:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:46:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:46:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:46:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:46:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:50:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:50:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:50:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:50:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:53:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:53:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:54:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:54:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:54:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:55:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:55:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:56:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:56:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:57:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:57:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:57:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:57:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:58:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:58:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:58:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:58:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:58:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 04:58:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:58:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 04:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:00:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:02:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:02:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:03:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:04:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:04:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:05:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:05:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:05:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:07:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:07:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:15:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:15:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:15:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:15:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:15:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:16:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:17:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:17:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:17:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:17:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:17:39 --> Severity: error --> Exception: Unsupported operand types: string * string C:\xampp\htdocs\webfreight\application\views\customers\booking.php 67
ERROR - 2021-05-06 05:17:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:17:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:17:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:20:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:20:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:22:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:22:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:22:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:22:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:22:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:22:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:22:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:23:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:23:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:31:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:31:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:32:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:32:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:33:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:33:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:34:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:34:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:34:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:34:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:37:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:38:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:38:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:38:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:38:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:39:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:39:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:39:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:40:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:40:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:40:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:40:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:41:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:41:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:41:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:41:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:42:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:42:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:42:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:42:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:43:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:43:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:43:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:43:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:43:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:43:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:43:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:43:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:49:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:49:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:53:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:53:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:53:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:53:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:53:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:53:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:54:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:54:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:55:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 05:56:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 05:56:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:00:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:00:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:05:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:05:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:07:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:07:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:08:04 --> Query error: Column 'total_amount' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-06', '10000035', 'JOBAN', '10000035AGLD', 'MELBOURNE', '3000', 'Perth', '6000', 'Overnight', 'Customer packaging', NULL, '', '', '', '', '', '', '44', '44', '44', '44', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-06 06:08:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 06:08:32 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 06:08:32 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 06:08:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:08:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:08:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 06:09:39 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 06:09:39 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 06:09:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:12:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:13:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:13:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:15:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:15:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:15:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:16:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:16:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:16:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:16:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:17:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:17:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:19:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:21:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:22:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:23:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:23:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:23:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:24:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:24:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:25:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:25:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:30:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 06:30:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 06:51:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:51:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:51:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:51:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:52:02 --> 404 Page Not Found: admin/Get_fix_rates/index
ERROR - 2021-05-06 06:52:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:52:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:52:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:52:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:52:55 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-05-06 06:53:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:53:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:53:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:53:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:53:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:53:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:53:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:53:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:53:43 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-05-06 06:54:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:54:07 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:54:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:54:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:54:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:54:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:54:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:54:43 --> 404 Page Not Found: admin/Get_fix_rates/index
ERROR - 2021-05-06 06:55:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:55:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:55:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:55:11 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:57:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:57:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 06:57:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 06:57:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-06 07:00:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:00:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:00:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:00:20 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:00:22 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-06 07:01:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:01:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:01:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:01:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:01:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:01:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:01:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:01:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:01:33 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-06 07:05:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:05:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:05:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:05:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:05:47 --> 404 Page Not Found: admin/Customers/admin
ERROR - 2021-05-06 07:06:00 --> 404 Page Not Found: admin/Customers/admin
ERROR - 2021-05-06 07:07:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:07:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:07:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:07:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:08:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:08:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:08:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:08:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:09:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:09:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:09:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:09:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:09:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:09:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:09:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:09:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:09:39 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:09:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:09:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:11:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:11:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:11:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:11:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:11:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:46 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 07:11:46 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-06 07:11:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:11:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:11:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:12:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:12:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:12:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:12:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:12:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:12:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:14:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:14:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:14:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:14:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:14:54 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:14:54 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:14:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:14:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:15:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:15:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:15:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:15:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:15:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:15:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:15:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:15:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:15:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:15:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:15:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:15:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:16:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:16:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:16:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:16:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:16:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:16:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:16:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:16:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:16:24 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:16:24 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:16:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:16:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:18:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:18:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:18:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:18:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:18:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:18:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:18:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:18:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:31 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:19:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:19:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:19:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:19:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:19:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:19:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:20:17 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:20:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:20:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:23:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:23:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:23:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:23:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:24:14 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:24:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 07:24:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:24:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:24:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:24:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:24:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:24:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:24:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:24:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:24:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:24:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:24:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:24:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 07:25:15 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 07:25:15 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 07:25:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:25:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:28:23 --> Severity: error --> Exception: Call to undefined function parseFloat() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:28:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:28:46 --> Severity: error --> Exception: Call to undefined function toFixed() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:28:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:30:47 --> Severity: error --> Exception: Call to undefined function toFixed() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:30:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:30:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:31:11 --> Severity: error --> Exception: Call to undefined function parseFloat() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:31:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:31:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:31:28 --> Severity: error --> Exception: Call to undefined function parseInt() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:31:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:31:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:32:52 --> Severity: error --> Exception: Call to undefined function parseInt() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:32:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:32:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:33:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:33:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:34:12 --> Severity: error --> Exception: Call to undefined function parseFloat() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:34:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:35:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:35:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:36:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:36:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:37:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:37:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:40:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:40:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:40:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:42:33 --> Severity: error --> Exception: Undefined constant "Math" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:42:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:42:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:43:36 --> Severity: error --> Exception: Call to undefined function toFixed() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:43:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:43:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:43:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:44:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:44:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:47:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:47:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:47:24 --> Severity: error --> Exception: Call to undefined function parseFloat() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 79
ERROR - 2021-05-06 07:47:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:47:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:47:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:49:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:49:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:49:48 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 291
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 45
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 55
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 62
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 70
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 80
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 365
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 417
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 426
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 438
ERROR - 2021-05-06 07:50:03 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 07:50:03 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 919
ERROR - 2021-05-06 07:50:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:50:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:50:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 07:50:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 07:55:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:55:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:55:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:55:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:57:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:57:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:57:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:57:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:57:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:57:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:57:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:57:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:59:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:59:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 07:59:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 07:59:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:00:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:00:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:00:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:00:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:03:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:03:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:03:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:03:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:03:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:03:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:03:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:03:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:04:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:04:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:04:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:04:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:04:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:04:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:04:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:04:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:06:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:06:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:06:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:06:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:06:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:06:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:06:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:06:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:08:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:08:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:08:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:08:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:08:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:08:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:08:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:08:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:09:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:09:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:10:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:10:00 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:10:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:10:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:10:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:10:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:11:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:11:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:11:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:11:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:11:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:11:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:11:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:11:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:13:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:13:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:13:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:13:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:13:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:13:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:13:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:13:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:16:47 --> 404 Page Not Found: customer/Address_book_export/index
ERROR - 2021-05-06 08:16:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:16:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:16:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:16:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:16:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:16:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:16:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:17:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:17:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:17:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:17:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:17:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:17:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:17:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:17:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 08:17:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 08:17:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:17:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:17:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:17:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:19:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:19:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:19:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:19:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:33:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:33:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:33:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:33:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:34:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:34:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:34:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:34:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:38:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:38:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:38:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:38:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:38:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:38:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:38:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:38:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:39:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:39:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:39:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:39:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:39:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:39:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:39:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:39:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:41:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:41:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:41:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:41:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:41:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:41:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:41:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:41:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:42:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:42:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:42:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:42:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:44:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:44:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:44:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:44:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:47:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:47:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:47:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:47:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:47:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:47:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:47:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:47:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:49:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:49:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:49:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:49:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:49:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:49:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:49:38 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:49:38 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:51:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:51:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:51:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:51:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:51:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:51:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:51:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:51:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:52:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:52:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:52:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:52:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:52:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:52:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:52:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:52:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:54:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:54:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:54:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:54:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:54:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:54:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:54:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:54:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:55:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:55:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:55:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:55:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:56:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:56:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:56:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:56:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:56:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:56:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:56:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:56:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:57:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:57:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:57:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:57:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:57:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:57:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:57:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:57:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:58:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:58:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:58:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:58:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:58:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:58:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 08:58:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 08:58:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:00:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:00:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:00:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:00:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:00:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:00:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:00:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:00:17 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:01:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:01:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:01:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:01:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:01:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:01:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:01:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:01:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:02:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:02:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:02:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:02:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:03:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:03:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:03:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:03:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:03:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:03:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:03:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:03:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:05:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:05:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-06 09:05:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:05:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:08:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:08:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:08:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:08:46 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:09:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:09:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:09:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:09:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:10:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:10:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:10:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:10:27 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:10:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:10:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:10:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:10:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:11:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:11:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:11:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:11:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:12:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:12:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:12:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:12:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:12:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:12:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:12:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:12:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:13:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:13:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:13:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:13:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:14:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:14:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:14:10 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:14:10 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:14:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:14:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:14:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:14:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:15:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:15:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:15:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:15:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:15:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:15:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:15:33 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:15:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:16:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:16:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:16:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:16:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:16:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:16:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:16:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:16:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:17:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:17:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:17:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:17:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:18:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:18:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:18:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:18:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:19:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:19:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:19:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:19:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:19:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:19:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:19:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:19:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:20:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:20:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 717
ERROR - 2021-05-06 09:20:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:20:11 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:20:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 712
ERROR - 2021-05-06 09:20:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 712
ERROR - 2021-05-06 09:20:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:20:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:23:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 712
ERROR - 2021-05-06 09:23:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 712
ERROR - 2021-05-06 09:23:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:23:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:24:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 712
ERROR - 2021-05-06 09:24:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 712
ERROR - 2021-05-06 09:24:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:24:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:26:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:26:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:26:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:26:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:28:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:28:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:28:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:28:14 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:28:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:28:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:28:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:28:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:29:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:29:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 09:29:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:29:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 09:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:30:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:30:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:30:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:30:26 --> 404 Page Not Found: customer/Shipment/settings_address_default_search.ix
ERROR - 2021-05-06 09:30:27 --> 404 Page Not Found: customer/Shipment/settings_address_default_search.ix
ERROR - 2021-05-06 09:30:42 --> 404 Page Not Found: customer/Shipment/settings_address_default_search.ix
ERROR - 2021-05-06 09:30:42 --> 404 Page Not Found: customer/Shipment/settings_address_default_search.ix
ERROR - 2021-05-06 09:30:43 --> 404 Page Not Found: customer/Shipment/settings_address_default_search.ix
ERROR - 2021-05-06 09:30:44 --> 404 Page Not Found: customer/Shipment/settings_address_default_search.ix
ERROR - 2021-05-06 09:43:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:43:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:43:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:43:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:43:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:43:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:43:43 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:43 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:45 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:45 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:43:45 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:45 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:43:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:46 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:43:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:47 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:43:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:47 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:43:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:43:48 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:43:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:44:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:44:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:44:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:44:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:44:21 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:44:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:44:22 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:47:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:47:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:48:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:03 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:03 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:48:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:04 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:48:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:06 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:48:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:07 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:48:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:48:08 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:50:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:50:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:50:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:51:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:33 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:51:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:34 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:51:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:35 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:51:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:51:36 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 227 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 09:53:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:53:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:53:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:53:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:54:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:54:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:54:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:54:07 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:54:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:54:08 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:54:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:54:09 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:54:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:54:10 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:54:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:54:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:54:20 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:55:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:55:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:10 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:11 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:12 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:12 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:13 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:13 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:14 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:14 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:14 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:15 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:15 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:15 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:15 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:15 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:15 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:15 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:16 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:16 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:17 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:17 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:18 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:55:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:55:20 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 09:56:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 09:57:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:57:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:57:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:57:07 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 09:57:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 09:57:07 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:04:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:04:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:04:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:04:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:05:03 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:05:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:05:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:05:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:14 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:15 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:16 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:06:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:07:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:07:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:07:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:07:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:07:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:07:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:07:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:07:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:08:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:08:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:08:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:09:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:09:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:09:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:09:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:09:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:09:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:09:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:10:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:10:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:10:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:10:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:10:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:11:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:11:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 10:11:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 10:11:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 10:11:41 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 10:11:59 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 10:11:59 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 10:11:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:11:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:12:22 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 10:12:22 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 10:12:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:12:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:12:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 10:12:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 10:12:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 10:12:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 10:13:15 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 10:13:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-06 10:13:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:13:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:13:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 10:13:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 718
ERROR - 2021-05-06 10:13:28 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 10:13:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-06 10:13:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:13:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:13:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:13:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:14:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:14:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:14:03 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:15:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:15:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:15:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:15:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:16:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:16:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:16:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:16:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:16:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:17:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:17:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:17:34 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:17:35 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:18:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:18:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:19:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:19:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea %' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:19:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea c%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:19:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea co%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:19:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:19:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea cor%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:20:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:20:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea %' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea c%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea co%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea cor%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea corp%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:20:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:20:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%sea corpo%' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:21:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:21:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:21:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:23 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:21:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea ' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:21:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea c' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:21:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea co' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:21:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:21:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea cor' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:23:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:23:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:51 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:23:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:30:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:30:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:30:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea ' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:30:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea c' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:30:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:30:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea co' AND 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:31:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:31:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:31:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'  10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea', 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:31:42 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'  10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea ', 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:31:43 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'  10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea c', 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:31:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'  10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea co', 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:31:44 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:31:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'  10000006
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE 'sea cor', 'customer_id'  10000006
 LIMIT 5
ERROR - 2021-05-06 10:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:34:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:35:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:35:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:35:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:35:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:35:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:39:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:39:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:39:16 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:39:16 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:39:17 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:40:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:40:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:40:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:40:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:40:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:40:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:40:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:41:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:41:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:41:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:42:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:42:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:36 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:38 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:45 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:42:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:43:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:43:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:24 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:43:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:17 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:28 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 228 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 10:44:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:29 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 228 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 10:44:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:30 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 228 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 10:44:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:30 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 228 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 10:44:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:44:33 --> Severity: error --> Exception: Too few arguments to function User_model::get_contact_data(), 1 passed in C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php on line 228 and exactly 2 expected C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 172
ERROR - 2021-05-06 10:45:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:45:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:45:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:42 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:42 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:43 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:43 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:45:43 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:46:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:46:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:47:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:47:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:47:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:47:02 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:48:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:48:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:48:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:48:42 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:51:45 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:45 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:46 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:51:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:48 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:51:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:48 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:51:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:48 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:51:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:51:50 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:52:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:52:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:52:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:29 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:52:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:30 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:52:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:31 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:52:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:32 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:52:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:52:32 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:57:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:57:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:57:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:05 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:57:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:06 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:57:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:07 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:57:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:08 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:57:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:57:08 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:58:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:58:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:58:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:07 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%SEA%', 'customer_id'
 LIMIT 5
ERROR - 2021-05-06 10:58:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%SEA %', 'customer_id'
 LIMIT 5
ERROR - 2021-05-06 10:58:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%SEA C%', 'customer_id'
 LIMIT 5
ERROR - 2021-05-06 10:58:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%SEA CO%', 'customer_id'
 LIMIT 5
ERROR - 2021-05-06 10:58:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' 'customer_id'
 LIMIT 5' at line 3 - Invalid query: SELECT *
FROM `address_book`
WHERE `company_name` LIKE '%SEA COR%', 'customer_id'
 LIMIT 5
ERROR - 2021-05-06 10:58:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:58:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:58:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:54 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:58:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:54 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:58:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:54 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:58:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:58:55 --> Severity: error --> Exception: Object of class CI_Session could not be converted to string C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 169
ERROR - 2021-05-06 10:59:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-06 10:59:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-06 10:59:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:59:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:59:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:59:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:59:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-06 10:59:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
