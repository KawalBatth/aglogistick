<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-29 02:13:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:13:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:13:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 02:13:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 02:13:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:13:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:13:24 --> 404 Page Not Found: admin/Auth/script.js
ERROR - 2021-04-29 02:13:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:13:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:13:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 02:54:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:54:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:54:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 02:54:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 02:55:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:55:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 02:55:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 02:55:47 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:01:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 713
ERROR - 2021-04-29 03:01:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 713
ERROR - 2021-04-29 03:01:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:01:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:01:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 713
ERROR - 2021-04-29 03:01:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 713
ERROR - 2021-04-29 03:01:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:01:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:08:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:08:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:09:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:09:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:10:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:10:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:10:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:10:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:11:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:11:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:14:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:14:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:15:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:15:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:16:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:16:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:16:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:16:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:17:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:17:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:18:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:18:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:19:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:19:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:20:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:20:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:22:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:22:31 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:23:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:23:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:23:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:23:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:23:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:23:40 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:24:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:24:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:34:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:34:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:35:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:35:01 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 03:36:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:36:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:44:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:44:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:45:25 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:45:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:50:26 --> Severity: error --> Exception: Call to undefined function mds() C:\xampp\htdocs\webfreight\application\controllers\user.php 36
ERROR - 2021-04-29 03:54:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 03:54:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:37:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 04:37:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 04:37:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 04:37:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 04:38:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:38:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:39:20 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:39:20 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:39:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:39:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 04:57:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 04:57:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 05:39:52 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 05:39:52 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 06:07:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:07:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:07:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:07:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:07:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:07:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:07:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:07:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:07:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:07:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:07:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:07:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:08:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:08:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:08:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:08:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:08:50 --> Severity: Warning --> Undefined variable $query C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 228
ERROR - 2021-04-29 06:08:50 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 228
ERROR - 2021-04-29 06:08:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:08:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:09:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:09:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 06:09:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:09:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 06:11:43 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 06:11:43 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 199
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 274
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 276
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 277
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 278
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 279
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 280
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 258
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 290
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1237
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1241
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1253
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1253
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1260
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1260
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1260
ERROR - 2021-04-29 07:49:21 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1287
ERROR - 2021-04-29 07:49:31 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 07:49:31 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 258
ERROR - 2021-04-29 07:49:31 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1280
ERROR - 2021-04-29 07:50:41 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 07:50:41 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 258
ERROR - 2021-04-29 07:50:41 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1280
ERROR - 2021-04-29 07:53:33 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 07:53:33 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 258
ERROR - 2021-04-29 07:53:33 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 1280
ERROR - 2021-04-29 07:53:59 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 07:54:57 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:01:41 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:03:02 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:03:50 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:06:38 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:06:58 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:07:35 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:07:58 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:09:54 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:14:04 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:14:47 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:16:33 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:16:53 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:17:24 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:19:32 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 08:27:02 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 08:27:02 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 08:27:30 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:28:49 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:31:34 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:35:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:35:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:35:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 08:35:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 08:36:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:36:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:36:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 08:36:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-04-29 08:37:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:37:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:37:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:37:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:38:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:38:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:38:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:38:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:40:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:40:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:40:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:40:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:41:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:41:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:41:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:41:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:42:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:42:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:42:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:42:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:45:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:45:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 705
ERROR - 2021-04-29 08:45:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:45:03 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-04-29 08:50:48 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:52:49 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:50 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:50 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:50 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:52 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:53 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:52:59 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:53:42 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:55:38 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:56:27 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 08:56:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:56:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:56:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:56:57 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:56:58 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:56:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:57:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:57:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 08:57:14 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:03:38 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:03:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:03:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:03:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:03:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:03:42 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:04:11 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:04:29 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:05:36 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:18:22 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-29 09:18:57 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 09:18:57 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-04-29 09:25:16 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:27:10 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:11 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:13 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:13 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:14 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:14 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:27:27 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:27:41 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:32:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:32:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:32:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:32:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-29 09:32:25 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:32:25 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 113
ERROR - 2021-04-29 09:37:03 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 09:43:25 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-29 10:56:09 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveSenderAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 286
ERROR - 2021-04-29 10:56:09 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveRecipientAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 292
ERROR - 2021-04-29 10:56:09 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-29 10:57:03 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-29 11:00:04 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
