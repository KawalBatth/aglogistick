<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-12 02:31:57 --> Severity: error --> Exception: Call to undefined method User_model::get_country() C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 78
ERROR - 2021-05-12 02:33:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:33:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:33:18 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:33:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:33:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:33:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:33:27 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 721
ERROR - 2021-05-12 02:33:27 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 721
ERROR - 2021-05-12 02:33:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:33:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:34:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:34:41 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:34:41 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 720
ERROR - 2021-05-12 02:34:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 720
ERROR - 2021-05-12 02:34:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:35:12 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:35:12 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:35:12 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 720
ERROR - 2021-05-12 02:35:12 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\admin\customers\customer_manage.php 720
ERROR - 2021-05-12 02:35:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:35:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:36:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:36:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:36:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:36:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:36:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:36:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 748
ERROR - 2021-05-12 02:36:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:36:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:38:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 750
ERROR - 2021-05-12 02:38:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 750
ERROR - 2021-05-12 02:38:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:38:54 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:39:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 750
ERROR - 2021-05-12 02:39:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 750
ERROR - 2021-05-12 02:39:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:39:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:41:48 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 750
ERROR - 2021-05-12 02:41:48 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 750
ERROR - 2021-05-12 02:41:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:41:48 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:49:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:49:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:49:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:49:24 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:50:27 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:50:27 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:50:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:50:27 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:50:46 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:50:46 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:50:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:50:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:50:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:50:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 02:50:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 02:50:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:03:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 04:03:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 04:03:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:03:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:04:25 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 04:04:25 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 04:04:25 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:04:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:06:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 04:06:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 753
ERROR - 2021-05-12 04:06:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:06:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:08:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:08:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 04:08:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:08:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:08:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:08:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:08:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:08:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:08:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:09:16 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:09:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:09:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:09:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:09:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:10:20 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:10:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:10:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:10:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:11:22 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:11:22 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:11:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:12:39 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:12:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 04:12:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:12:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:13:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:13:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:14:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:14:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:14:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:14:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:15:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:15:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 04:15:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:15:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 04:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:17:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:17:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:18:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:19:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:19:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:19:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:22:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:22:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:22:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:22:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:23:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:23:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:24:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:26:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:28:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:29:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:29:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:31:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:31:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:31:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:32:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:32:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:32:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:32:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:32:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:32:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:33:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:33:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:33:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:33:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:33:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:34:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:34:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:34:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:35:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:35:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:35:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:39:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:39:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:39:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:40:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:40:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:40:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:40:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:40:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:41:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:41:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:42:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:42:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:42:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:42:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:42:59 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:43:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:43:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:43:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-12 04:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:44:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:45:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:45:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:46:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:46:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:46:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:46:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:46:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:47:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:47:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:47:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:47:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:47:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:48:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:48:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:49:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:50:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:50:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:51:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:51:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:51:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:51:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:51:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:51:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:51:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:52:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:52:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:53:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-12 04:53:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-12 04:53:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:53:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:53:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:53:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:54:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:54:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:54:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:54:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:54:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:54:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:54:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:56:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:56:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:56:23 --> Severity: error --> Exception: syntax error, unexpected token "else", expecting end of file C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 254
ERROR - 2021-05-12 04:56:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:56:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:56:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:56:45 --> Severity: error --> Exception: syntax error, unexpected token "else", expecting end of file C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 254
ERROR - 2021-05-12 04:56:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:56:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:57:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:57:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:57:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:57:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:57:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:58:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:58:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:59:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:59:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:59:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:59:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:59:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 04:59:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 04:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:10:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:11:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:11:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:12:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:12:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 296
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:12:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:13:38 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:15:35 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:18:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:18:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:19:29 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:21:49 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:22:35 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-12 05:22:35 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-12 05:22:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:22:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:22:41 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-12 05:22:41 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-12 05:22:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:22:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:22:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:22:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:22:53 --> Severity: Warning --> Undefined variable $country C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-12 05:22:53 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 91
ERROR - 2021-05-12 05:22:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:22:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:23:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:23:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:23:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 296
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:24:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 337
ERROR - 2021-05-12 05:27:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'webnew' C:\xampp\htdocs\webfreight\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-12 05:27:25 --> Unable to connect to the database
ERROR - 2021-05-12 05:28:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:28:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 296
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:43 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-12 05:28:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:28:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:30:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 05:30:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 05:30:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 05:30:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 05:30:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 05:30:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 05:30:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 05:30:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-12 05:31:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:31:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:33:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:33:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:33:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:33:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:33:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:33:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:37:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:37:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:40:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:40:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:41:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:41:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:42:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:42:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:42:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:42:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:42:49 --> Query error: Unknown column 'sender_contact' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `sender_contact`, `sender_email`, `sender_phone`, `sender_address`, `sender_city`, `sender_pin`, `sender_state`, `sender_company`, `sender_country`, `receiver_contact`, `receiver_company`, `receiver_address`, `receiver_email`, `receiver_phone`, `receiver_city`, `receiver_pin`, `receiver_state`, `receiver_country`, `shipapi_res`) VALUES ('10000035', '11', 'testing', '454545', 'eereer', '343433', '1', 'JOBAN', 'BATTH', '54545  ', 'T', 'melbourne', '45555454', '3000', 'VIC', '2021-05-12', '12:00:00', '17:30:00', '1', '1', 'Front Desk', 'BATTH', 'kawalbatth89@gmail.com', '45555454', '54545    ', 'MELBOURNE', '3000', 'VIC', 'JOBAN', 'Australia', '3232', '32323', '2323  ', 'rab@gmail.com', '0876543212', 'Melbourne', '3000', 'VIC', 'Australia', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"oysK0EqX_Q0AAAF5zoIdll6r\",\"shipment_reference\":\"454545\",\"shipment_creation_date\":\"2021-05-12T13:42:49+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":40.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"Z.wK0EqX0tYAAAF50IIdll6r\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001583FPP00001\",\"consignment_id\":\"111Z50001583\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":490.33,\"total_cost_ex_gst\":445.75,\"shipping_cost\":445.75,\"total_gst\":44.58,\"freight_charge\":445.75,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-12T13:42:49+10:00\"}]}')
ERROR - 2021-05-12 05:43:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:43:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:55:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:55:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 05:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 05:55:53 --> Query error: Unknown column 'receiver_city' in 'field list' - Invalid query: INSERT INTO `additional_details` (`customer_id`, `carrier_id`, `content_desc`, `billing_ref`, `special_delivery`, `collection_ref`, `schedule_select`, `collect_company`, `collect_Contact_name`, `collect_address`, `collect_address1`, `collect_city`, `collect_phone`, `contact_postal_code`, `collect_state`, `ready_date`, `collect_ready_time`, `collect_close_time`, `collect_pickup_location`, `collect_location_code`, `collect_location_description`, `sender_contact`, `sender_email`, `sender_phone`, `sender_address`, `sender_city`, `sender_pin`, `sender_state`, `sender_company`, `sender_country`, `receiver_contact`, `receiver_company`, `receiver_address`, `receiver_email`, `receiver_phone`, `receiver_city`, `receiver_pin`, `receiver_state`, `receiver_country`, `shipapi_res`) VALUES ('10000035', '11', 'rererer', '4343434', 'fdfdfdf', '4343434', '1', 'JOBAN', 'BATTH', '54545  ', 'T', 'MELBOURNE', '45555454', '3000', 'VIC', '2021-05-12', '12:00:00', '17:30:00', '1', '1', 'Front Desk', 'BATTH', 'kawalbatth89@gmail.com', '45555454', '54545    ', 'MELBOURNE', '3000', 'VIC', 'JOBAN', 'Australia', '5454', '454', 'tetete  ', 'reo@gmail.com', '054545454545', 'Melbourne', '3000', 'VIC', 'Australia', '{\"warnings\":[{\"message\":\"Safe Drop is not available for use with this product.\",\"field\":\"shipments[0].items[0].safe_drop_enabled\"}],\"shipments\":[{\"shipment_id\":\"tPEK0EapEYAAAAF5TXsdiV63\",\"shipment_reference\":\"4343434\",\"shipment_creation_date\":\"2021-05-12T13:55:53+10:00\",\"email_tracking_enabled\":true,\"items\":[{\"weight\":33.000,\"authority_to_leave\":false,\"allow_partial_delivery\":false,\"item_id\":\"mEgK0EapGbAAAAF5TnsdiV63\",\"item_reference\":\"SKU-1\",\"tracking_details\":{\"article_id\":\"111Z50001586FPP00001\",\"consignment_id\":\"111Z50001586\"},\"product_id\":\"FPP\",\"item_summary\":{\"status\":\"Created\"},\"item_contents\":[],\"packaging_type\":\"CTN\"}],\"options\":{},\"shipment_summary\":{\"total_cost\":632.61,\"total_cost_ex_gst\":575.10,\"shipping_cost\":575.10,\"total_gst\":57.51,\"freight_charge\":575.10,\"status\":\"Created\",\"tracking_summary\":{\"Created\":1},\"number_of_items\":1},\"movement_type\":\"DESPATCH\",\"charge_to_account\":\"05028762\",\"shipment_modified_date\":\"2021-05-12T13:55:53+10:00\"}]}')
ERROR - 2021-05-12 06:00:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:00:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:00:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:01:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-12 06:01:13 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 3
ERROR - 2021-05-12 06:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:01:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:01:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:01:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 79
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 79
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 105
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 105
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 158
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 158
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 168
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 168
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 180
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 180
ERROR - 2021-05-12 06:02:01 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 398
ERROR - 2021-05-12 06:02:01 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 398
ERROR - 2021-05-12 06:02:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:12 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-12 06:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:02:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:02:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:06:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:09:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:09:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:09:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:09:58 --> 404 Page Not Found: customer/Add_booking/index
ERROR - 2021-05-12 06:10:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:10:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:11:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:11:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:11:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:11:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:11:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:11:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:11:33 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 06:11:41 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:11:43 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:11:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:11:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:11:58 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:12:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:12:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:13:02 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 06:13:18 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 06:14:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:14:03 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:14:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:14:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:14:29 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 06:15:07 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:15:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:15:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:15:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:15:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:15:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:15:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:15:51 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:15:51 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:16:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:16:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:16:16 --> 404 Page Not Found: customer/Track/index
ERROR - 2021-05-12 06:16:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:16:29 --> 404 Page Not Found: Customers/track
ERROR - 2021-05-12 06:16:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:16:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:16:52 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:19:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:19:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:19:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:19:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:22:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:22:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:22:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:22:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:22:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:22:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:22:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:22:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:22:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:26:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:26:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:27:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:27:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:27:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:27:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:27:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:27:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:27:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:27:42 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:27:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:27:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:27:58 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:27:59 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:28:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:28:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:28:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:28:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:29:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:29:28 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:29:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 06:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:29:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:30:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:30:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 06:30:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 06:30:13 --> 404 Page Not Found: Track/index
ERROR - 2021-05-12 07:09:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:09:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 07:09:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 07:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:09:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:09:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:09:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:10:00 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 07:11:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:11:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:11:06 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 07:11:12 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 07:11:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 07:11:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:11:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:15:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:15:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:15:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:16:01 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 07:16:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 07:16:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:16:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:17:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:17:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:17:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:23:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:23:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 07:56:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 07:56:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:01:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:25:54 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 08:25:54 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-12 08:25:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:25:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:26:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:27:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:27:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:27:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:27:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:27:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:27:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:27:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:27:42 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 08:27:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 08:27:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:27:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 08:28:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 08:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 237
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 360
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 362
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 363
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 364
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 365
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 366
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 367
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 368
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 369
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 296
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 2
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 33
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 37
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 51
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 51
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 162
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 163
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 164
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 166
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 167
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 176
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 177
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 178
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 179
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 180
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 181
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 277
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 282
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 287
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 298
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 306
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 311
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 316
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 498
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.country" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 499
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 501
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 502
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 503
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 504
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 505
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 506
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 507
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 507
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 507
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 511
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 512
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 513
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 514
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 515
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 516
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 517
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 518
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 518
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 518
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.country" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 519
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 522
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 523
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 524
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 525
ERROR - 2021-05-12 09:19:04 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 526
ERROR - 2021-05-12 09:19:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 09:19:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 09:19:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 09:19:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 48
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 79
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 105
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 158
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 168
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 180
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "country" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 842
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 1351
ERROR - 2021-05-12 09:19:10 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 1743
ERROR - 2021-05-12 09:19:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 09:19:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 09:19:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 09:19:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 09:19:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 09:19:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 09:19:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 09:19:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 09:19:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 09:19:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 09:51:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 09:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 09:52:08 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 09:52:08 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 09:52:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 09:52:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 10:17:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:30:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:30:19 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 10:37:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:37:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:41:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:41:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:42:00 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 10:42:03 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Undefined array key "consignment" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 4
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Undefined array key "tracking_id" C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 5
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 19
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 31
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 42
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 46
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 47
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 10:42:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\webfreight\application\views\customers\tracking.php 70
ERROR - 2021-05-12 10:42:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:42:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:42:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 10:42:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 10:42:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 10:42:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 10:43:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 10:43:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 759
ERROR - 2021-05-12 10:43:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 10:43:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-12 10:43:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:43:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:43:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:43:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:44:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:44:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:45:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:45:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:46:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:46:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:47:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:47:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:48:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:48:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:51:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:51:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-12 10:52:07 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 10:52:13 --> Severity: Warning --> Undefined array key "url" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 869
ERROR - 2021-05-12 10:52:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-12 10:52:53 --> 404 Page Not Found: Assets/css
