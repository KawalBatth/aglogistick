<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-23 02:59:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'webnew' C:\xampp\htdocs\webfreight\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-23 02:59:52 --> Unable to connect to the database
ERROR - 2021-04-23 03:01:44 --> Query error: Unknown column 'is_dangerous' in 'where clause' - Invalid query: SELECT *
FROM `surcharges_list`
WHERE `carrier_id` = '11'
AND `is_dangerous` IS NULL
ERROR - 2021-04-23 03:01:48 --> Query error: Unknown column 'is_dangerous' in 'where clause' - Invalid query: SELECT *
FROM `surcharges_list`
WHERE `carrier_id` = '11'
AND `is_dangerous` IS NULL
ERROR - 2021-04-23 04:09:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:09:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:09:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:09:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:09:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:09:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:09:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=787&shipmentPage.receiverAddress.phone=78777877&shipmentPage.receiverAddress.contactName=778&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=12&shipmentPage.receiverAddress.address=7878787&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=Tipperary&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:09:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=787&shipmentPage.receiverAddress.phone=78777877&shipmentPage.receiverAddress.contactName=778&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=12&shipmentPage.receiverAddress.address=7878787&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=Tipperary&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:09:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=787&shipmentPage.receiverAddress.phone=78777877&shipmentPage.receiverAddress.contactName=778&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=12&shipmentPage.receiverAddress.address=7878787&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=Tipperary&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 266
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 267
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 04:09:54 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `shipment` () VALUES ('')
ERROR - 2021-04-23 04:09:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 266
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 267
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Undefined variable $customerCode C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 04:16:52 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `shipment` () VALUES ('')
ERROR - 2021-04-23 04:16:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 04:17:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:17:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:17:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:17:54 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:17:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:17:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:17:55 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:18:03 --> Severity: Warning --> Undefined variable $customerCode C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 04:18:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=7676&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=767&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=4&shipmentPage.receiverAddress.address=565&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=rtrtt&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:18:18 --> Severity: Warning --> Undefined variable $customerCode C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 04:18:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=7676&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=767&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=4&shipmentPage.receiverAddress.address=565&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=rtrtt&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:18:28 --> Severity: Warning --> Undefined variable $customerCode C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 04:18:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=7676&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=767&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=4&shipmentPage.receiverAddress.address=565&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=rtrtt&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:20:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=78787&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=7787&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=236&shipmentPage.receiverAddress.address=&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=uuiuiu&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:23:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=0&shipmentPage.receiverAddress.address=&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:25:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gm...' at line 1 - Invalid query: INSERT INTO `shipment` (customerCode=&companyName=Kawaljit&phone=0846573646&contactName=Batth&email=kawalbatth@gmail.com&shipmentPage.senderAddress.country=12&shipmentPage.senderAddress.address=49 a Arkana  &shipmentPage.senderAddress.address2=&shipmentPage.senderAddress.address3=&shipmentPage.senderAddress.alternateUserName=&shipmentPage.senderAddress.city=Perth&shipmentPage.senderAddress.postalCode=6105&shipmentPage.senderAddress.state=WA&shipmentPage.receiverAddress.companyName=&shipmentPage.receiverAddress.phone=&shipmentPage.receiverAddress.contactName=&shipmentPage.receiverAddress.email=&shipmentPage.receiverAddress.country=0&shipmentPage.receiverAddress.address=&shipmentPage.receiverAddress.address2=&shipmentPage.receiverAddress.address3=&shipmentPage.receiverAddress.city=&shipmentPage.receiverAddress.postalCode=&shipmentPage.receiverAddress.state=&shipping_date=2021-04-23&shipmentPage.serviceId=11&shipmentPage.shipmentTypeId=&shipmentPage.packageId=3&shipmentPage.contentType=WPX&shipmentPage.weightUnit=KG&shipmentPage.dimensionUnit=CM&shipmentPage.currencyCode=AUD&shipmentPage.pieces.weight=&total_weight=&service_kg=&shipmentPage.pieces.dimensionL1=&shipmentPage.pieces.dimensionW1=&shipmentPage.pieces.dimensionH1=&get_volume=&shipmentPage.pieces.quantity1=1&final_total=&shipmentPage.isAddPiece=true&shipmentPage.addCons[1].addConName=Authorized to Leave (ATL)&shipmentPage.addCons[1].addConCode=atl&shipmentPage.addCons[1].listProperties[0].addConDetailName=Where to leave&shipmentPage.addCons[1].listProperties[0].addConDetailCode=atltoleave&shipmentPage.addCons[1].listProperties[0].value=) VALUES ('')
ERROR - 2021-04-23 04:59:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 04:59:04 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 04:59:07 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 04:59:08 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 04:59:08 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 04:59:09 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 04:59:09 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 04:59:09 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 05:01:08 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 05:02:03 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 05:25:16 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 05:25:37 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 06:12:58 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 06:28:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:28:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:28:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:28:26 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:28:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:28:27 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:29:03 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 06:29:03 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:03 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:03 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-04-23 06:29:03 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 394
ERROR - 2021-04-23 06:29:06 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 06:29:06 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:06 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:06 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-04-23 06:29:06 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 394
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 267
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 273
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 274
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveSenderAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.residentialPickup" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 276
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.alternateUserName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 277
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 278
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 279
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 280
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 283
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 286
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 287
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 288
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveRecipientAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 289
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.residentialDelivery" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 290
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 291
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 292
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 293
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipping_date" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 295
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 296
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.packageId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 297
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.contentType" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 298
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 299
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.dimensionUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 300
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.currencyCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 303
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 304
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 305
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 306
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "final_total" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 309
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 312
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.addConName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.addConCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 314
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.packName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.packCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 319
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.packvalue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 320
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 321
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.addMsgDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 322
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 323
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.authorityName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.authorityCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 326
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 327
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 328
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined array key "shipmentPage.authorityMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 329
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-04-23 06:29:18 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 394
ERROR - 2021-04-23 06:29:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 06:30:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:18 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:30:19 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 06:31:16 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-23 06:31:16 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 06:31:16 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:31:16 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:31:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:31:16 --> Severity: Warning --> Undefined variable $ttyt C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-04-23 06:31:16 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 394
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 264
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 267
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 273
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 274
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveSenderAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.residentialPickup" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 276
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.alternateUserName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 277
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 278
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 279
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 280
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 283
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 286
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 287
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 288
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveRecipientAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 289
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.residentialDelivery" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 290
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 291
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 292
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 293
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipping_date" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 295
ERROR - 2021-04-23 06:31:33 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 296
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.packageId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 297
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.contentType" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 298
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 299
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.dimensionUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 300
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.currencyCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 303
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 304
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 305
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 306
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "final_total" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 309
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 312
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.addConName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.addConCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 314
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.packName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.packCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 319
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.packvalue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 320
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 321
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.addMsgDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 322
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 323
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.authorityName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.authorityCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 326
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 327
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 328
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined array key "shipmentPage.authorityMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 329
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-04-23 06:31:34 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 394
ERROR - 2021-04-23 06:31:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 06:31:48 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 06:32:33 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 06:32:36 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 06:32:47 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 06:32:52 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 07:01:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 07:01:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 07:01:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 07:01:41 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:02:01 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:02:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:02:03 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:02:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:02:04 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:02:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:02:05 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:02:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 265
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 273
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 274
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveSenderAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 276
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.residentialPickup" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 277
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.alternateUserName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 278
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 279
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 280
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 283
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 286
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 287
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 288
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 289
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveRecipientAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 290
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.residentialDelivery" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 291
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 292
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 293
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipping_date" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 295
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 296
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 297
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.packageId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 298
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.contentType" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 299
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 300
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.dimensionUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.currencyCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 302
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 304
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 305
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 306
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 307
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "final_total" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.addConName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 314
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.addConCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.packName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 319
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.packCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 320
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.packvalue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 321
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 322
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.addMsgDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 323
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.authorityName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 326
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.authorityCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 327
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 328
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 329
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined array key "shipmentPage.authorityMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 330
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:02:11 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:02:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:02:38 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:02:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:03:01 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:03:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:03:03 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:03:03 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:03:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Undefined variable $767676 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:03:09 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:03:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 265
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 273
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 274
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveSenderAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 276
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.residentialPickup" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 277
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.alternateUserName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 278
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 279
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 280
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 283
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 286
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 287
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 288
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 289
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveRecipientAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 290
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.residentialDelivery" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 291
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 292
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 293
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipping_date" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 295
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 296
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 297
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.packageId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 298
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.contentType" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 299
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 300
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.dimensionUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.currencyCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 302
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 304
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 305
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 306
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 307
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "final_total" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.addConName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 314
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.addConCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.packName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 319
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.packCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 320
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.packvalue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 321
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 322
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.addMsgDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 323
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.authorityName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 326
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.authorityCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 327
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 328
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 329
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined array key "shipmentPage.authorityMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 330
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:03:39 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:03:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 265
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 268
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 269
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 270
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 271
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 272
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 273
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 274
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 275
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveSenderAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 276
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.residentialPickup" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 277
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.alternateUserName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 278
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 279
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 280
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 281
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 282
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.phone" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 283
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 284
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.email" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.country" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 286
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 287
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 288
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address3" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 289
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.isSaveRecipientAddressBook" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 290
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.residentialDelivery" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 291
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 292
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 293
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipping_date" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 295
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 296
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 297
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.packageId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 298
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.contentType" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 299
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 300
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.dimensionUnit" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.currencyCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 302
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 304
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 305
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 306
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 307
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "final_total" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 310
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 311
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 313
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.addConName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 314
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.addConCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 317
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined variable $Array C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 318
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.packName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 319
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.packCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 320
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.packvalue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 321
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.addConDetailMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 322
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.addMsgDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 323
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.msgValue" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 324
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.authority.value" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 325
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.authorityName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 326
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.authorityCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 327
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailName" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 328
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.authorityDetailCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 329
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined array key "shipmentPage.authorityMsg" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 330
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Undefined variable $ C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-04-23 07:03:41 --> Severity: error --> Exception: Call to undefined method Auth_model::save_shipment() C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 395
ERROR - 2021-04-23 07:03:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-04-23 07:03:51 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 07:04:19 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 07:18:36 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 08:56:59 --> Severity: Warning --> Undefined property: stdClass::$state C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-04-23 09:36:43 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
ERROR - 2021-04-23 10:48:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:39 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:40 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-04-23 10:48:47 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 10:48:47 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 10:48:47 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-04-23 10:49:18 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 188
