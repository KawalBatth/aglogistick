<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-04 02:30:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'webnew' C:\xampp\htdocs\webfreight\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-05-04 02:30:23 --> Unable to connect to the database
ERROR - 2021-05-04 02:31:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:31:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:31:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:31:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:32:53 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:32:53 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:32:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:32:53 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:33:09 --> 404 Page Not Found: admin/DelUser/107
ERROR - 2021-05-04 02:33:13 --> 404 Page Not Found: admin/DelUser/107
ERROR - 2021-05-04 02:33:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:33:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:34:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:34:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:34:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:34:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:34:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:34:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:35:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:35:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:35:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:36:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:36:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:37:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:37:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:41:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:41:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:42:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:42:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 02:42:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:42:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 02:44:19 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 02:44:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:44:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:44:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:44:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:45:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 02:45:02 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 02:45:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:45:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:45:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:45:38 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 02:45:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 02:45:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Contact" C:\xampp\htdocs\webfreight\application\controllers\Members.php 67
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Company" C:\xampp\htdocs\webfreight\application\controllers\Members.php 68
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "State" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Postcode" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 75
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 89
ERROR - 2021-05-04 02:56:38 --> Query error: Unknown column 'created' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `state`, `postcode`, `address`, `address1`, `phone`, `city`, `email`, `country`, `department`, `deafult_billing_type`, `fax`, `account_number`, `residential_address`, `default_service_type`, `default_package_type`, `created`, `modified`) VALUES ('10000035', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-04 02:56:38', '2021-05-04 02:56:38')
ERROR - 2021-05-04 02:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-05-04 03:02:33 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:02:35 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:02:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:02:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:02:59 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:02:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:03:06 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:03:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:03:11 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:03:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:03:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:04:16 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 03:04:16 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 03:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:04:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:04:19 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 519
ERROR - 2021-05-04 03:04:19 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 520
ERROR - 2021-05-04 03:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:04:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:06:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:06:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:06:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:06:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:06:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:08:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:08:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:08:15 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:08:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:14:10 --> Query error: Table 'webfreight.address_book' doesn't exist - Invalid query: SELECT *
FROM `address_book`
ERROR - 2021-05-04 03:14:37 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:14:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:14:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:14:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:14:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:14:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:14:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:14:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:14:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:15:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:16:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:16:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:16:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:16:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:16:33 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:16:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:16:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:16:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:16:48 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:16:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:18:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:18:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:18:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:18:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:18:23 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:18:23 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:18:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:18:23 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:18:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:18:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:19:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:19:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:19:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:19:32 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:20:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:20:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:20:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:20:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:20:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:20:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:20:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:20:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:20:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:20:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:20:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:22:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:22:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:22:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:22:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:24:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:24:14 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 03:24:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:24:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:27:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:27:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:27:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:27:08 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:34:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:34:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:34:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:34:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:35:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:35:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:35:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:35:45 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:37:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:37:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:37:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:37:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:37:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:37:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:37:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 217
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 291
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 293
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 294
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 295
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 296
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 297
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 298
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 299
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 300
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 276
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 81
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 134
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 135
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 136
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 137
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 139
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 140
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 149
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 150
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 151
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 152
ERROR - 2021-05-04 03:41:20 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 153
ERROR - 2021-05-04 03:41:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:41:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:41:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:41:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:41:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 03:41:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 03:41:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:41:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:41:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:41:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:42:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:42:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:42:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:42:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 03:43:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:43:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:43:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:43:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:43:20 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:43:20 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:43:20 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:43:20 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:45:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:45:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:45:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:45:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:46:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:46:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:46:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:46:13 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:47:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:47:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:47:55 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:47:56 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:48:02 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-04 03:48:14 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-04 03:49:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:49:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:49:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:49:26 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:49:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:49:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:49:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:49:35 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:50:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:50:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:50:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:50:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:50:32 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:50:32 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:50:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:50:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:51:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:51:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:51:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:51:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:53:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:53:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:53:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:53:02 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:54:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:54:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:54:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:54:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:55:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:55:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:55:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:55:22 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:58:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:58:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:58:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:58:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:59:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:59:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 03:59:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 03:59:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:01:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:01:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:01:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:01:34 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:03:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:03:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:03:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:03:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:05:01 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:05:01 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:05:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:05:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:06:33 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:06:33 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:06:33 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:06:33 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:07:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:07:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:07:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:07:51 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:09:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:09:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:09:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:09:09 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:10:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:10:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:10:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:10:36 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:11:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:11:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:11:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:11:48 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:12:59 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:12:59 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:12:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:12:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:14:22 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:14:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:14:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:14:23 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:16:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:16:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:16:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:16:37 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:18:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:18:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:18:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:18:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:19:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:19:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:19:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:19:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:20:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:20:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:20:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:20:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:21:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:21:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:21:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:21:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:22:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:22:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:22:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:22:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:24:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:24:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:24:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:24:07 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:24:51 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:24:51 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:24:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:24:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:25:31 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:25:31 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:25:31 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:25:32 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:26:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:26:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:26:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:26:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:27:04 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:27:04 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:27:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:27:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:32:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:32:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:32:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:32:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:36:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:36:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:36:54 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:36:54 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 04:36:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:36:54 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 04:36:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:36:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:39:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:39:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:39:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:39:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:39:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:39:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:39:30 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:39:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:39:33 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:41:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:41:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:41:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:41:00 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:41:01 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:43:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:50:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:50:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:50:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:50:46 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:50:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:50:47 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:50:48 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:04 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:05 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:06 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:20 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:21 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:22 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:51:25 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 04:53:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 04:57:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 04:57:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:01:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:06:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:06:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:06:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 05:06:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 05:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:06:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:06:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:06:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:06:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:08:07 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:08:07 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:08:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:08:08 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:08:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:08:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:08:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:08:12 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:09:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:11:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:11:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:11:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:11:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:11:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:11:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:11:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:12:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:12:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:12:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:12:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:12:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:12:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:12:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:12:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:14:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:14:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:14:30 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:14:30 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:14:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:14:30 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:15:26 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:15:26 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:15:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:15:26 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:17:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:17:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:17:06 --> 404 Page Not Found: Public/dist
ERROR - 2021-05-04 05:17:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:17:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:17:49 --> 404 Page Not Found: Public/dist
ERROR - 2021-05-04 05:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:18:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:18:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:18:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:18:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:18:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:18:56 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:18:56 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:18:56 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:18:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:19:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:19:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:19:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:19:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:19:35 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:19:35 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:19:35 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:19:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:21:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:21:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:21:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:21:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:21:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:21:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:22:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:22:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:23:10 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:23:10 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:23:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:23:10 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:23:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:23:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:23:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:23:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:23:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:23:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:23:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:23:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:25:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:25:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:28:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:28:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:28:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:28:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:29:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:29:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:29:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:29:00 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:29:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:29:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:29:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:29:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:29:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:29:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:29:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:29:42 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:30:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:30:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:30:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:30:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:30:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:30:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:30:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:30:21 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:30:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:30:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:30:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:30:43 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:32:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:32:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:33:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:33:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:33:13 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:33:13 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:33:13 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:33:14 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:33:34 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:33:34 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:33:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:33:34 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:34:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:34:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:34:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:34:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:34:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:34:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:34:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:34:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:36:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:36:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:36:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:36:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:37:02 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:37:02 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:37:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:37:02 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:38:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:38:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:38:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:38:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:39:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:39:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:39:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:39:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:41:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:41:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:41:05 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:41:06 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:42:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:42:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:42:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:42:09 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:43:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:43:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:43:45 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:43:45 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:43:45 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:43:46 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:44:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:44:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:45:16 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:45:16 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:45:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:45:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:45:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:45:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:45:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:45:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:45:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:45:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:45:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:45:57 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:46:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:46:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:46:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:46:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:47:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:47:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:47:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:47:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:47:38 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:47:38 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:47:38 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:47:39 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:48:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:48:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:48:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:48:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:48:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:48:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:49:55 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:49:55 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:49:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:49:55 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:50:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:50:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:50:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:50:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:51:25 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:51:25 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:51:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:51:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:51:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:51:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:51:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:51:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:51:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:51:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:51:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:52:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:52:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:52:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:52:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:52:38 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:52:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:52:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:52:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:52:56 --> Query error: Unknown column 'default_package_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('10000032', 'Test', 'test', 'test', '3334', '44', '443', '4343', '44', 'KAWALBATTH@GMAIL.COM', '3', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-04 05:53:08 --> Query error: Unknown column 'default_package_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('10000032', 'Test', 'test', 'test', '3334', '44', '443', '4343', '44', 'KAWALBATTH@GMAIL.COM', '3', '4343', '4343', '1', '1', '1', '4343', '1')
ERROR - 2021-05-04 05:53:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:53:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:53:20 --> Query error: Unknown column 'default_package_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-04 05:55:17 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('10000032', 'Test', 'test', 'test', '3334', '44', '443', '4343', '44', 'KAWALBATTH@GMAIL.COM', '3', '4343', '4343', '1', '1', '1', '4343', '1')
ERROR - 2021-05-04 05:55:23 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:55:23 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:55:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:55:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:55:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:55:36 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('10000032', 'kawal', '656566', '54545', '45454544', 'Melbourne', 'VIC', '3000', '65656', 'KAWALBATTH@GMAIL.COM', '2', '4545', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-04 05:55:47 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('10000032', 'kawal', '656566', '54545', '45454544', 'Melbourne', 'VIC', '3000', '65656', 'KAWALBATTH@GMAIL.COM', '2', '4545', '55', '1', '1', '2', '65656', '1')
ERROR - 2021-05-04 05:55:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:55:56 --> Query error: Unknown column 'deafult_billing_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-04 05:56:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 05:56:24 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 05:56:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:56:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:56:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:56:36 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:56:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:56:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:56:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:56:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 05:56:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 05:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:56:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:57:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:57:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:57:07 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:57:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:57:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:57:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:58:06 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:58:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:58:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:58:17 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:58:17 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:58:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:58:17 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:58:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:58:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 05:58:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:58:52 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 05:59:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:15 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 05:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:59:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 05:59:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 05:59:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:59:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 05:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 05:59:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:00:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:00:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:00:37 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:00:37 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:00:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:00:37 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:00:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:00:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:00:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:03:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:04:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:04:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:04:40 --> Severity: Warning --> Undefined variable $addressId C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 585
ERROR - 2021-05-04 06:04:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:04:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:05:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:05:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:05:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:05:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:05:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:05:58 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:08:42 --> Severity: error --> Exception: Call to undefined function alert() C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 589
ERROR - 2021-05-04 06:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:08:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:09:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:09:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:09:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:09:18 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 06:09:18 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 06:09:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:09:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:09:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:09:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:09:25 --> Severity: error --> Exception: Call to undefined function get_address_book() C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 4
ERROR - 2021-05-04 06:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:10:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:10:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:10:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:10:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:10:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:10:57 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 06:10:57 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-04 06:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:10:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:10:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:10:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:11:05 --> Severity: error --> Exception: Call to undefined function get_address_book() C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 4
ERROR - 2021-05-04 06:11:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:11:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:14:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:14:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:15:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:15:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:15:14 --> Severity: error --> Exception: Call to undefined function get_address_book() C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 4
ERROR - 2021-05-04 06:15:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 06:15:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 06:16:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:16:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:16:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:16:44 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:59:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:59:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:59:49 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:59:50 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 06:59:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:59:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 06:59:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 06:59:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:03 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:10 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:00:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:01:09 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:01:09 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:01:11 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:01:11 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:01:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:01:12 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:01:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:01:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:01:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 07:01:16 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 07:02:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:02:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:02:19 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 07:02:20 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 07:03:50 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-05-04 07:04:01 --> 404 Page Not Found: admin/Get_rates/index
ERROR - 2021-05-04 07:04:28 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:04:28 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:04:28 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 07:04:29 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-04 07:04:50 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:04:50 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:04:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:04:50 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:04:53 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-04 07:05:03 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-04 07:05:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:05:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:05:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:05:18 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:05:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:06:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:06:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:06:16 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:22 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:30 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:06:34 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:05 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:07:05 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:07:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:07:05 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:11 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:16 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:19 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:07:49 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:07:49 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:07:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:07:49 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:07:58 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:07:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:07:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:07:59 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:01 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:29 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:08:29 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:08:29 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:08:30 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:08:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:08:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 07:08:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:08:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:08:54 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\admin\Customers.php 186
ERROR - 2021-05-04 07:09:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:09:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:12:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 22
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 22
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 57
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 57
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 67
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 67
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 74
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 74
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 82
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 82
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-04 07:12:36 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 641
ERROR - 2021-05-04 07:12:36 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 641
ERROR - 2021-05-04 07:12:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:12:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:15:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:15:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:17:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:17:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:17:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:18:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:18:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:19:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:19:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:19:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:45:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:45:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:45:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:45:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:51:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:51:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:51:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:51:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:51:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 07:51:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:59:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 07:59:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:00:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:00:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:00:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:09:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:09:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:10:31 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\webfreight\application\views\customers\layout.php 62
ERROR - 2021-05-04 08:10:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:10:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:10:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:11:05 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\webfreight\application\views\customers\layout.php 62
ERROR - 2021-05-04 08:11:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:11:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:15:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:15:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:16:06 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 08:16:06 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 08:16:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 08:16:06 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 08:16:24 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 08:16:24 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 08:16:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 08:16:24 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 08:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:16:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:17:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:17:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:18:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:19:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:22:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:22:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:24:35 --> Severity: Warning --> include(include/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 55
ERROR - 2021-05-04 08:24:35 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 55
ERROR - 2021-05-04 08:24:35 --> Severity: Warning --> Undefined variable $view C:\xampp\htdocs\webfreight\application\views\settings\layout.php 67
ERROR - 2021-05-04 08:24:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:25:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:25:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:26:04 --> Severity: Warning --> include(include/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 55
ERROR - 2021-05-04 08:26:04 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 55
ERROR - 2021-05-04 08:26:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:26:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:26:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:26:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:31:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:33:37 --> Severity: Warning --> include(include/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 55
ERROR - 2021-05-04 08:33:37 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 55
ERROR - 2021-05-04 08:33:37 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:33:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:33:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:33:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:33:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:34:47 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:34:47 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:34:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:34:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:35:14 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:35:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:35:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:35:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:35:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:36:03 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:36:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:36:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:36:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:36:40 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 08:36:40 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-04 08:36:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 08:36:40 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-04 08:37:03 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:37:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:37:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:37:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:30 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:38:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-04 08:38:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:38:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:40:12 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionL1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 08:40:12 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 08:40:12 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 08:40:12 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 08:40:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:40:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:41:22 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 08:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:41:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:41:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 08:50:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 08:50:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:03:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:03:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:04:37 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:04:37 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionW1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 09:04:37 --> Severity: Warning --> Undefined array key "shipmentPage.pieces.dimensionH1" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 54
ERROR - 2021-05-04 09:04:37 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:04:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:04:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:06:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:06:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:07:05 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:07:05 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:07:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:07:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:08:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:08:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:09:01 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:09:01 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:09:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:09:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:09:42 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:09:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:09:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:09:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:09:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:11:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:11:47 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:11:47 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:11:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:11:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:11:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:11:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:13:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:13:28 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:13:28 --> Severity: error --> Exception: Unsupported operand types: string + string C:\xampp\htdocs\webfreight\application\views\customers\booking.php 77
ERROR - 2021-05-04 09:13:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:13:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:13:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:13:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:13:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:13:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:14:12 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:14:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:14:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:14:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:14:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:14:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:14:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:14:37 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:14:37 --> Severity: error --> Exception: Unsupported operand types: string + string C:\xampp\htdocs\webfreight\application\views\customers\booking.php 77
ERROR - 2021-05-04 09:14:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:14:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:14:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:14:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:15:13 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:15:13 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:15:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:15:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:15:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:15:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:15:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:15:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:18:15 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:18:15 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:18:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:18:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:18:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:18:51 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:18:51 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 74
ERROR - 2021-05-04 09:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:18:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:18:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:19:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:21:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:22:06 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:22:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:22:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:23:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:23:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:29:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:29:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:30:17 --> Severity: Warning --> Undefined array key "isdangerous" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 301
ERROR - 2021-05-04 09:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:30:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:30:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:30:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:30:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:30:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:30:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:31:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:31:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:31:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:31:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $get_carrier C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $get_service C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 85
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 138
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 138
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 139
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 139
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 140
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 140
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 141
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 141
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 152
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 152
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 153
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 153
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 154
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 154
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 155
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 155
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 252
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 252
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 257
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 257
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 262
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 262
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 272
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 272
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 280
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 280
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 285
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 285
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 290
ERROR - 2021-05-04 09:33:37 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 290
ERROR - 2021-05-04 09:33:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:36:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:36:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:36:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:37:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 3
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $get_carrier C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $get_service C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $quote_value C:\xampp\htdocs\webfreight\application\views\customers\booking.php 85
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 138
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 138
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 139
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 139
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 140
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 140
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 141
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 141
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 152
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 152
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 153
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 153
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 154
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 154
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 155
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 155
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $result C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-04 09:37:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 252
ERROR - 2021-05-04 09:37:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 252
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 257
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 257
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 262
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 262
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 272
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 272
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 280
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 280
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 285
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 285
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\booking.php 290
ERROR - 2021-05-04 09:37:09 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 290
ERROR - 2021-05-04 09:39:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:43:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:43:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:43:36 --> Severity: error --> Exception: Call to undefined function get_address_book() C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 4
ERROR - 2021-05-04 09:43:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:44:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:56:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:56:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 09:57:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 09:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:02:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:02:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:03:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:03:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:23:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:23:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:23:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:24:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:24:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:51:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:51:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 22
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 22
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 57
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 57
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 67
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 67
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 74
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 74
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 82
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 82
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-04 10:52:21 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 641
ERROR - 2021-05-04 10:52:21 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 641
ERROR - 2021-05-04 10:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:53:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:53:08 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 10:53:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 10:53:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 10:53:09 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 10:53:29 --> 404 Page Not Found: customer/Webship_search_cityix/index
ERROR - 2021-05-04 10:53:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 22
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 22
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 57
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 57
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 67
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 67
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 74
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 74
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 82
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 82
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 103
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 155
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 164
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 176
ERROR - 2021-05-04 10:54:02 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 641
ERROR - 2021-05-04 10:54:02 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 641
ERROR - 2021-05-04 10:55:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-04 10:55:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-04 10:55:27 --> 404 Page Not Found: Assets/css
