<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-05 02:27:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:27:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:27:03 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:27:04 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:30:36 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:30:36 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:30:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:30:36 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:31:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:31:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:31:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:31:15 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:31:41 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:31:41 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:31:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:31:41 --> 404 Page Not Found: admin/Scriptjs/index
ERROR - 2021-05-05 02:32:43 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:32:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:32:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:32:43 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:32:47 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-05 02:32:58 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-05 02:34:21 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:34:21 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:34:21 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:34:38 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-05 02:34:43 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-05 02:34:52 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-05 02:35:14 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:35:14 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:35:14 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:41:39 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:41:39 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:41:39 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:41:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:41:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:41:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:41:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:42:19 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:42:19 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:42:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:42:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:42:25 --> 404 Page Not Found: admin/Customers/customers
ERROR - 2021-05-05 02:42:57 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:42:57 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:42:57 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:42:58 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:43:03 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:43:03 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:43:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:43:04 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:44:00 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:44:00 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 02:44:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:44:01 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 02:44:29 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:44:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:44:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:44:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:46:53 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:46:53 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:46:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:46:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:48:00 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:48:00 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:48:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:48:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:48:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:48:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:51:29 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:51:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:51:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:58:42 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:58:43 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:58:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:58:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:58:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:59:19 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:59:19 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:59:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:59:45 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:59:45 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 02:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 02:59:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 02:59:45 --> 404 Page Not Found: customer/Scriptjs/index
ERROR - 2021-05-05 02:59:45 --> 404 Page Not Found: customer/Scriptjs/index
ERROR - 2021-05-05 03:00:15 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:00:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:00:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:00:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:00:41 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:00:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:00:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:01:11 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:01:11 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:01:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:01:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:01:26 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:01:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:01:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:01:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:02:09 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:02:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:02:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:02:27 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:02:27 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:02:42 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:02:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:02:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:03:35 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:03:35 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:03:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:03:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:03:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:04:25 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:04:25 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:04:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:04:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:04:42 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:04:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:04:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:04:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:04:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:04:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:05:27 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:05:27 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:05:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:05:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:05:35 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:05:35 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:05:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:05:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:06:30 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:06:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:06:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:06:38 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:06:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:06:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:06:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:06:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:06:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:07:16 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:07:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:07:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:07:30 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:07:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:07:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:07:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:08:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:08:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:08:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:08:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:08:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:09:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:09:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:09:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:09:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:09:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:09:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:09:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:08 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 03:10:08 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 03:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:10:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:10:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:11:02 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:11:02 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 03:11:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:11:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:11:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:11:41 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:08 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:12:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-05-05 03:12:24 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 629
ERROR - 2021-05-05 03:12:24 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 629
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:12:50 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 285
ERROR - 2021-05-05 03:18:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:18:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:24 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:46 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:18:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:18:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:19:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:22:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:28 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:22:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:22:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:23:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:23:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:25 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:23:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:23:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:23:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:23:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:23:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 376
ERROR - 2021-05-05 03:24:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:24:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:30:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:30:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:30:58 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:13 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 316
ERROR - 2021-05-05 03:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:31:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:32:47 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 03:32:47 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 03:32:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 03:32:47 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 03:33:18 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 03:33:18 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 03:33:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 03:33:19 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 03:33:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:33:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:34:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:34:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:34:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:34:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:34:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:42:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:42:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:42:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:42:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:43:06 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 315
ERROR - 2021-05-05 03:44:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:46:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:47:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:28 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:29 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:31 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:32 --> 404 Page Not Found: customer/Settings_address_default_searchix/index
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-05-05 03:47:49 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 629
ERROR - 2021-05-05 03:47:49 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 629
ERROR - 2021-05-05 03:48:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:48:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:49:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:49:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:54:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:56:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:56:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:57:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:57:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:59:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:59:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 03:59:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 03:59:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:00:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:00:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:00:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:00:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:12:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:12:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:12:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:12:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:13:07 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 04:13:07 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 04:13:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:13:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:13:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:13:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:13:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:13:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:16:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:16:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:16:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:16:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:17:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:17:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:18:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:18:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:20:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:21:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:21:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:21:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:21:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:22:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:22:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:24:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:24:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:24:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:25:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:25:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:26:07 --> Severity: error --> Exception: Call to undefined function alert() C:\xampp\htdocs\webfreight\application\views\customers\quote.php 78
ERROR - 2021-05-05 04:26:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:26:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:26:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:26:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:27:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:27:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:28:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:28:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:29:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:29:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:29:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:29:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:29:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:30:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:31:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:31:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:31:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:31:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:31:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:32:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:32:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:32:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:32:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:32:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:35:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:35:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:35:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:37:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:37:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:56:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:56:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:57:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:57:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:57:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:57:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:57:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:57:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 04:57:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 90
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 142
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 151
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 163
ERROR - 2021-05-05 04:58:31 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-05-05 04:58:31 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 628
ERROR - 2021-05-05 05:04:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:04:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:04:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:04:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:05:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:05:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:05:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:05:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:05:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:05:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:06:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:06:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:26 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 05:07:26 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 05:07:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:07:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:08:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:08:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:08:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:08:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:08:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:08:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:08:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:09:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 05:09:23 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 05:09:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:09:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:09:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:09:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:09:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:09:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:09:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:10:24 --> Query error: Unknown column 'last_modified' in 'field list' - Invalid query: UPDATE `address_book` SET `contact_name` = 'JOBAN', `company_name` = 'AGTWW', `state` = 'SYD', `postcode` = '3000', `address` = '45 ARK', `address1` = '444', `phone` = '65656', `city` = 'SYDNEY', `email` = 'KAWALBATTH@GMAIL.COM', `country` = '0', `department` = '', `deafult_billing_type` = '0', `fax` = '', `account_number` = '', `residential_address` = NULL, `default_service_type` = '0', `default_package_type` = '0', `last_modified` = '2021/05/05 05:10:24'
WHERE `id` = '5519'
ERROR - 2021-05-05 05:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:11:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:11:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:12:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:12:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:16:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:16:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:17:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:17:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:19:53 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 698
ERROR - 2021-05-05 05:19:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 698
ERROR - 2021-05-05 05:19:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:19:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:20:17 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 698
ERROR - 2021-05-05 05:20:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 698
ERROR - 2021-05-05 05:20:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:20:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:20:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:20:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:20:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:20:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:20:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:20:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:23:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:23:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:23:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:24:21 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 05:24:21 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 05:24:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:24:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:24:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:24:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:24:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:24:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:25:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:25:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:26:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:26:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:27:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:27:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:27:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:27:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:27:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:27:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:27:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:27:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:27:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:27:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:42:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:42:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:43:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:43:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:44:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:44:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:45:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:45:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:46:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:46:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:46:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:46:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:46:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:46:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:50:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:50:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:50:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:50:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:52:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:52:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:52:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:52:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:52:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:53:02 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 542
ERROR - 2021-05-05 05:53:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 542
ERROR - 2021-05-05 05:53:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:53:15 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 542
ERROR - 2021-05-05 05:53:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 542
ERROR - 2021-05-05 05:53:59 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 542
ERROR - 2021-05-05 05:53:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:53:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:54:07 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 542
ERROR - 2021-05-05 05:55:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:55:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:55:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:55:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:56:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:56:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:57:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 05:57:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:57:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 05:57:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:05:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:05:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:05:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:05:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:06:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:06:24 --> 404 Page Not Found: customer/Customers/shipmentundefined
ERROR - 2021-05-05 06:06:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:06:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:06:42 --> 404 Page Not Found: customer/Shipmentundefined/index
ERROR - 2021-05-05 06:07:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:07:18 --> 404 Page Not Found: customer/Shipment/undefined
ERROR - 2021-05-05 06:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:08:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:09:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:09:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:09:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:10:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:10:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:10:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:10:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:11:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:11:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:11:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:11:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:12:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:12:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:12:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:12:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:12:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:13:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:14:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:14:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:14:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:14:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:14:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:14:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:14:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:14:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:14:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:15:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:15:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:15:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:15:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:15:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:16:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:16:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:16:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:18:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:18:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:21:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:22:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:22:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:22:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:22:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:22:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:22:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:22:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:22:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:22:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:23:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:23:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:23:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:23:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:24:05 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:25:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:25:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:25:28 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 15
ERROR - 2021-05-05 06:25:28 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 15
ERROR - 2021-05-05 06:25:28 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 516
ERROR - 2021-05-05 06:25:28 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 516
ERROR - 2021-05-05 06:25:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:25:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:25:40 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 15
ERROR - 2021-05-05 06:25:40 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 15
ERROR - 2021-05-05 06:25:40 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 516
ERROR - 2021-05-05 06:25:40 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 516
ERROR - 2021-05-05 06:25:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:25:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:25:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:26:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:26:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:26:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:27:04 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 15
ERROR - 2021-05-05 06:27:04 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 15
ERROR - 2021-05-05 06:27:04 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 516
ERROR - 2021-05-05 06:27:04 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\address_book.php 516
ERROR - 2021-05-05 06:27:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:27:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:27:29 --> 404 Page Not Found: customer/Add_address_book/index
ERROR - 2021-05-05 06:28:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:07 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 06:28:07 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 06:28:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 06:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 06:28:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:15:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:23:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:23:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:27:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 07:27:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:27:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:27:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:27:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:29:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:29:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:29:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:29:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:29:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:12 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:30:12 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:30:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:30:52 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:30:52 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:30:52 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:30:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:30:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:30:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:31:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:31:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:31:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:31:16 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:31:16 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:31:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:31:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:31:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:35:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:35:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:35:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:35:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:35:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:35:43 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:35:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:35:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:36:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:36:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:36:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:36:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:36:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:36:23 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:36:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:36:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:36:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:36:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:36:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:36:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:36:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:36:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:37:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:37:11 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:37:11 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 07:37:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:37:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:37:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:37:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:37:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:37:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:38:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:38:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:38:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:38:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:38:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:44:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:44:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:45:45 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\webfreight\application\controllers\Members.php 85
ERROR - 2021-05-05 07:45:45 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\Members.php 86
ERROR - 2021-05-05 07:45:45 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:45:45 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 95
ERROR - 2021-05-05 07:45:45 --> Query error: Unknown column 'customer_id' in 'field list' - Invalid query: INSERT INTO `members` (`customer_id`, `name`, `email`, `phone`, `created`, `modified`) VALUES ('10000035', NULL, NULL, NULL, '2021-05-05 07:45:45', '2021-05-05 07:45:45')
ERROR - 2021-05-05 07:52:14 --> Query error: Unknown column 'customer_id' in 'field list' - Invalid query: UPDATE `members` SET `customer_id` = '10000035', `name` = 'JOBAN', `email` = 'kawalbatth89@gmail.com', `phone` = '54545', `modified` = '2021-05-05 07:52:14'
WHERE `email` = 'kawalbatth89@gmail.com'
ERROR - 2021-05-05 07:52:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:52:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:52:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:52:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:53:49 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:53:49 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:53:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:54:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:54:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:54:50 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:54:50 --> Query error: Column 'phone' cannot be null - Invalid query: INSERT INTO `members` (`name`, `email`, `phone`, `created`, `modified`) VALUES ('JOBAN', 'zora@gmail', NULL, '2021-05-05 07:54:50', '2021-05-05 07:54:50')
ERROR - 2021-05-05 07:55:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:55:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 07:55:24 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:55:24 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:55:24 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:55:24 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 87
ERROR - 2021-05-05 07:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 07:55:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "State/Province" C:\xampp\htdocs\webfreight\application\controllers\Members.php 69
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Address#" C:\xampp\htdocs\webfreight\application\controllers\Members.php 71
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Address1" C:\xampp\htdocs\webfreight\application\controllers\Members.php 72
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Phone" C:\xampp\htdocs\webfreight\application\controllers\Members.php 73
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "City" C:\xampp\htdocs\webfreight\application\controllers\Members.php 74
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 75
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 89
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Undefined array key "Email" C:\xampp\htdocs\webfreight\application\controllers\Members.php 97
ERROR - 2021-05-05 08:02:04 --> Query error: Unknown column 'modified' in 'field list' - Invalid query: UPDATE `address_book` SET `customer_id` = '10000035', `contact_name` = 'Joban', `company_name` = 'HLB', `state` = NULL, `postcode` = NULL, `address` = NULL, `address1` = NULL, `phone` = NULL, `city` = NULL, `email` = NULL, `country` = NULL, `department` = NULL, `deafult_billing_type` = NULL, `fax` = NULL, `account_number` = NULL, `residential_address` = NULL, `default_service_type` = NULL, `default_package_type` = NULL, `modified` = '2021-05-05 08:02:04'
WHERE `email` IS NULL
ERROR - 2021-05-05 08:02:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-05-05 08:10:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Country" C:\xampp\htdocs\webfreight\application\controllers\Members.php 76
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Department" C:\xampp\htdocs\webfreight\application\controllers\Members.php 77
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Defaul_billing" C:\xampp\htdocs\webfreight\application\controllers\Members.php 78
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Fax" C:\xampp\htdocs\webfreight\application\controllers\Members.php 79
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Account_number" C:\xampp\htdocs\webfreight\application\controllers\Members.php 80
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Residential_address" C:\xampp\htdocs\webfreight\application\controllers\Members.php 81
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Default_service" C:\xampp\htdocs\webfreight\application\controllers\Members.php 82
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Undefined array key "Default_package" C:\xampp\htdocs\webfreight\application\controllers\Members.php 83
ERROR - 2021-05-05 08:10:22 --> Query error: Unknown column 'created' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `state`, `postcode`, `address`, `address1`, `phone`, `city`, `email`, `country`, `department`, `deafult_billing_type`, `fax`, `account_number`, `residential_address`, `default_service_type`, `default_package_type`, `created`, `modified`) VALUES ('10000035', 'Kawal', 'HYF', '', NULL, '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-05-05 08:10:22', '2021-05-05 08:10:22')
ERROR - 2021-05-05 08:10:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\webfreight\system\core\Exceptions.php:271) C:\xampp\htdocs\webfreight\system\core\Common.php 570
ERROR - 2021-05-05 08:12:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:12:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:12:48 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:12:48 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:12:48 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:12:48 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:12:48 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:12:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:12:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:14:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:14:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:15:53 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:15:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:15:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:20:59 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:20:59 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:20:59 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:20:59 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:20:59 --> Severity: Warning --> Undefined array key "Postal Code" C:\xampp\htdocs\webfreight\application\controllers\Members.php 70
ERROR - 2021-05-05 08:21:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:22:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:22:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:28:25 --> Query error: Table 'webfreight.address_book' doesn't exist - Invalid query: SELECT *
FROM `address_book`
WHERE `customer_id` = '10000035'
ERROR - 2021-05-05 08:28:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:28:57 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:32:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:32:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:32:59 --> Query error: Unknown column 'default_package_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES ('10000035', 'kawal', '656566', '54545', '45454544', 'Melbourne', 'VIC', '3000', '65656', 'KAWALBATTH@GMAIL.COM', 'Albania', '', '', '0', '0', '0', '', NULL)
ERROR - 2021-05-05 08:33:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:33:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:33:11 --> Query error: Unknown column 'default_package_type' in 'field list' - Invalid query: INSERT INTO `address_book` (`customer_id`, `contact_name`, `company_name`, `address`, `address1`, `city`, `state`, `postcode`, `phone`, `email`, `country`, `department`, `fax`, `default_service_type`, `default_package_type`, `deafult_billing_type`, `account_number`, `residential_address`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 08:34:23 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 08:34:23 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 08:34:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:34:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:34:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:34:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:34:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 08:34:37 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 08:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:34:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:34:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:35:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:35:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:35:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:36:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:36:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:36:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:37:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:48:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:48:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:48:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:48:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:48:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:48:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:49:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:49:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:51:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:51:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:51:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:51:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:52:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:52:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:52:56 --> Severity: error --> Exception: Undefined constant "selected" C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 501
ERROR - 2021-05-05 08:52:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:52:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:54:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:54:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:54:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:54:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:54:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:54:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:55:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:55:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:58:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:58:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:58:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:40 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:40 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 08:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 08:59:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:00:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:00:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:01:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:07:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:07:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:07:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:07:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:07:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:07:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:07:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:07:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:08:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:08:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:08:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:08:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:08:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:09:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:09:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:09:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:09:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:10:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:10:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:10:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:10:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:11:42 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:11:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:11:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:11:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:14:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:14:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:14:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:14:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:14:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:14:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:15:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:15:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:16:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:17:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:17:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:17:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:17:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:17:35 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:17:56 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:18:11 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:18:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:18:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:18:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:18:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:19:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:21:33 --> Query error: Unknown column 'receiver_city' in 'field list' - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_city`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLQ', 'MELBOURNE', '3000', 'WA', '6000', 'Overnight', 'Customer packaging', '3.00', NULL, '', '', '', '', '', '', '3', '65', '40', '135', '1', 'VIC', 'Star Track', '')
ERROR - 2021-05-05 09:21:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:22:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:22:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:22:23 --> Query error: Unknown column 'receiver_city' in 'field list' - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_city`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLH', 'MELBOURNE', '3000', 'WA', '6000', 'Overnight', 'Customer packaging', '66.00', NULL, '', '', '', '', '', '', '66', '66', '66', '66', '1', 'VIC', 'Star Track', '')
ERROR - 2021-05-05 09:22:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:22:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:22:33 --> Query error: Unknown column 'receiver_city' in 'field list' - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_city`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`) VALUES ('2021-05-05', NULL, NULL, 'AGLE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:23:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:23:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:24:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:24:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 09:25:05 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 09:25:05 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 09:28:40 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLK', 'MELBOURNE', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '33.00', '', '', '', '', '', '', '33', '33', '33', '33', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:28:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:28:55 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLR', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:29:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:29:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:29:17 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLJ', 'MELBOURNE', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '166.00', '', '', '', '', '', '', '166', '66', '66', '66', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:29:28 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:29:34 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLY', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:32:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:32:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:33:12 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLJ', 'MELBOURNE', '3000', NULL, '6000', 'Road Express', 'Customer packaging', '1.00', '', '', '', '', '', '', '1', '3', '33', '33', '3', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:33:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:33:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:33:22 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:34:38 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 09:34:56 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 09:34:56 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 09:34:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:34:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:35:04 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`) VALUES ('2021-05-05', NULL, NULL, 'AGLR', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:35:58 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:35:58 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:36:25 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLU', 'Melbourne', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '44.00', '', '', '', '', '', '', '44', '44', '4', '4', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:36:28 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLW', 'Melbourne', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '44.00', '', '', '', '', '', '', '44', '44', '4', '4', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:37:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:37:21 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLR', 'MELBOURNE', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '55.00', '', '', '', '', '', '', '55', '55', '55', '55', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:38:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:38:20 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLE', 'MELBOURNE', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '44.00', '', '', '', '', '', '', '44', '44', '44', '44', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:38:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:38:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:38:44 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:40:26 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLH', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:40:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:40:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:40:52 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLY', 'MELBOURNE', '3000', NULL, '6000', 'Road Express', 'Customer packaging', '44.00', '', '', '', '', '', '', '44', '44', '44', '44', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:40:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:40:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:41:03 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLK', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:42:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:42:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:43:16 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLR', 'MELBOURNE', '3000', NULL, '6000', 'Overnight', 'Customer packaging', '44.00', '', '', '', '', '', '', '44', '44', '44', '44', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:43:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:43:27 --> Query error: Column 'customer_name' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLR', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> Severity: Warning --> Undefined property: stdClass::$service_id C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 375
ERROR - 2021-05-05 09:51:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:51:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:51:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:51:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:51:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:51:31 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:51:50 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000035', 'JOBAN', '10000035AGLP', 'MELBOURNE', '3000', NULL, '6000', 'Road Express', 'Customer packaging', '33.00', '', '', '', '', '', '', '33', '3', '333', '33', '1', 'VIC', 'Star Track', '', 'WA')
ERROR - 2021-05-05 09:52:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:52:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:52:37 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 09:53:42 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 09:53:42 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 09:53:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 09:53:42 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 09:54:00 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:54:00 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:54:14 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 291
ERROR - 2021-05-05 09:54:23 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 291
ERROR - 2021-05-05 09:54:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 09:54:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 09:54:49 --> Query error: Column 'receiver_suburb' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', '10000034', 'TEST17', '10000034AGLB', 'Perth', '6000', NULL, '3000', 'Overnight', 'Customer packaging', '33.00', '', '', '', '', '', '', '33', '33', '33', '33', '1', 'WA', 'Star Track', '', 'VIC')
ERROR - 2021-05-05 10:00:10 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:00:10 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:00:28 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 291
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:00:43 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:00:43 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:00:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:00:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:00:52 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLN', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:37 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:37 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:38 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:38 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 9
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "customerName" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 44
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "phone" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 54
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "contact_name" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 61
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "email" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 69
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "address" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 362
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "city" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 414
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "postal_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 423
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Attempt to read property "state_code" on null C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 435
ERROR - 2021-05-05 10:03:39 --> Severity: Warning --> Undefined variable $services C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:39 --> Severity: error --> Exception: count(): Argument #1 ($var) must be of type Countable|array, null given C:\xampp\htdocs\webfreight\application\views\customers\shipment.php 909
ERROR - 2021-05-05 10:03:48 --> Query error: Column 'customer' cannot be null - Invalid query: INSERT INTO `quote` (`quote_date`, `customer`, `customer_name`, `quote_number`, `sender_suburb`, `sender_postcode`, `receiver_suburb`, `receiver_postcode`, `shipment_type`, `package_type`, `total_amount`, `receiver_phone`, `receiver_company`, `receiver_contact`, `receiver_email`, `receiver_address`, `receiver_address1`, `quote_weight`, `quote_length`, `quote_width`, `quote_height`, `quote_quantity`, `sender_state`, `servicename`, `receiver_country`, `receiver_state`) VALUES ('2021-05-05', NULL, NULL, 'AGLJ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-05 10:04:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:04:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:05:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:05:30 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 291
ERROR - 2021-05-05 10:05:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:05:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:06:29 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:07:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:08:08 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 10:08:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 10:08:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:08:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:14:21 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 10:14:21 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 10:14:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:14:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:14:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:14:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:14:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:14:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:15:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:15:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:15:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:15:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:15:23 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:15:23 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:15:24 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:15:52 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 10:15:52 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 10:15:52 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 10:15:53 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 10:16:17 --> Severity: Warning --> include(include/control_sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 10:16:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\webfreight\application\views\settings\layout.php 81
ERROR - 2021-05-05 10:16:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:16:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:16:52 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:16:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:16:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:17:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:17:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:17:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:17:07 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:17:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:17:09 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:17:15 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 10:17:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 10:17:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 10:17:15 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 10:17:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:17:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:17:44 --> Severity: Warning --> Undefined variable $note C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 10:17:44 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\webfreight\application\views\admin\include\navbar.php 711
ERROR - 2021-05-05 10:17:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 10:17:44 --> 404 Page Not Found: admin/Customers/script.js
ERROR - 2021-05-05 10:18:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:18:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:18:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:18:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:19:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:20:37 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:20:37 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:20:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:20:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:20:46 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:20:46 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:13 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:22 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:29:22 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:29:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:36 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:44 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:29:49 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:32:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:32:03 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:32:13 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:32:13 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:32:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:32:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:32:30 --> Query error: Unknown column 'last_modified' in 'field list' - Invalid query: UPDATE `address_book` SET `contact_name` = 'kawaljit', `company_name` = '656566', `state` = 'VIC', `postcode` = '3000', `address` = '54545', `address1` = '45454544', `phone` = '65656', `city` = 'Melbourne', `email` = '', `country` = '2', `department` = '', `deafult_billing_type` = '0', `fax` = '', `account_number` = '', `residential_address` = NULL, `default_service_type` = '0', `default_package_type` = '0', `last_modified` = '2021/05/05 10:32:30'
WHERE `id` = '5515'
ERROR - 2021-05-05 10:33:51 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:33:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:34:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:40:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:41:02 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:41:02 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:41:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:41:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:41:16 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:41:16 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:41:18 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:41:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:41:41 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:21 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:32 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:32 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:41 --> Severity: Warning --> Undefined variable $customers C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:43:41 --> Severity: Warning --> Attempt to read property "customer_id" on null C:\xampp\htdocs\webfreight\application\views\customers\address_book_add.php 17
ERROR - 2021-05-05 10:43:43 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:47 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:47 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:43:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:43:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:44:04 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:44:04 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:50:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:50:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:50:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:50:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:50:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:50:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:50:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:50:30 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:50:45 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:50:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:51:16 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:51:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Undefined variable $address_book C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:53:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> Severity: Warning --> Undefined array key "customer_id" C:\xampp\htdocs\webfreight\application\views\customers\quote.php 82
ERROR - 2021-05-05 10:53:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:53:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:54:01 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:54:01 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:55:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:55:55 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:55:59 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:55:59 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:56:12 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:56:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:56:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:56:20 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:56:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:06 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:58:06 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:08 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:58:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:58:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:25 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:58:34 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:58:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 10:58:50 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:54 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 10:58:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Attempt to read property "formdata" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 232
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key 1 C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 336
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 338
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 339
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 340
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 341
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.state" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 342
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 343
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.shipmentTypeId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 344
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.serviceId" C:\xampp\htdocs\webfreight\application\controllers\customer\Customers.php 345
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Attempt to read property "sender_zone" on null C:\xampp\htdocs\webfreight\application\models\admin\User_model.php 291
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Attempt to read property "carrier_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 31
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Attempt to read property "service_name" on null C:\xampp\htdocs\webfreight\application\views\customers\booking.php 35
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "total_weight" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.weightUnit" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 47
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 142
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 143
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 144
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 145
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 147
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.senderAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 148
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.companyName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 156
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.contactName" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 157
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 158
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.address2" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 159
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.postalCode" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 160
ERROR - 2021-05-05 11:01:14 --> Severity: Warning --> Undefined array key "shipmentPage.receiverAddress.city" C:\xampp\htdocs\webfreight\application\views\customers\booking.php 161
ERROR - 2021-05-05 11:01:14 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:17 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:19 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:22 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:01:33 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:48 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:01:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:02:27 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:03:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:03:39 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2021-05-05 11:03:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-05-05 11:03:42 --> 404 Page Not Found: Assets/bootstrap
