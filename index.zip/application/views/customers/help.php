<div class="portlet box">
                        <div class="portlet-header">
                            <div class="caption">AGL Help</div>
                            <div class="tools">
                                <i class="fa fa-chevron-up"></i><i class="fa fa-times"></i>
                            </div>
                        </div>
                        <div class="portlet-body">
                            <div class="panel-body pan">
                                <div class="form-body pal">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <p class="help_info">
                                                For information about your account or AGL Web Freight, please contact your local AGL office:
                                            </p><br>

                                            <p class="help_contact">
                                                Customer Service<br>
                                                08 94793399<br>
                                                webfreight@agllogistics.com
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>